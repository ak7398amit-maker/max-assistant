package com.max.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Speaks text: ElevenLabs voice if configured, otherwise the phone's own text-to-speech. */
class Speaker(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var player: MediaPlayer? = null
    private var pendingDone: (() -> Unit)? = null
    private var generation = 0

    init {
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) applyLanguage()
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                fire()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                fire()
            }
        })
    }

    fun applyLanguage() {
        val t = tts ?: return
        if (!ttsReady) return
        val loc = Languages.locale(Prefs.lang(ctx))
        var r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = t.setLanguage(Locale("hi", "IN"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                t.setLanguage(Locale.ENGLISH)
            }
        }
    }

    private fun fire() {
        main.post {
            val cb = pendingDone
            pendingDone = null
            cb?.invoke()
        }
    }

    fun speak(raw: String, onDone: (() -> Unit)?) {
        val text = clean(raw)
        stop()
        pendingDone = onDone
        if (text.isEmpty()) {
            fire()
            return
        }
        val gen = ++generation
        val elKey = Prefs.get(ctx, Prefs.K_EL_KEY).trim()
        val elVoice = Prefs.get(ctx, Prefs.K_EL_VOICE).trim()
        if (elKey.isNotEmpty() && elVoice.isNotEmpty()) {
            Thread {
                val f = try {
                    fetchEleven(text, elKey, elVoice)
                } catch (e: Exception) {
                    null
                }
                main.post {
                    if (gen != generation) return@post
                    if (f != null) playFile(f, text) else speakTts(text)
                }
            }.start()
        } else {
            main.post { if (gen == generation) speakTts(text) }
        }
    }

    private fun clean(s: String): String =
        s.replace("*", "").replace("#", "").replace("`", "").replace("_", " ").trim().take(3500)

    private fun speakTts(text: String) {
        val t = tts
        if (t == null || !ttsReady) {
            fire()
            return
        }
        applyLanguage()
        val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "max-utt")
        if (r != TextToSpeech.SUCCESS) fire()
    }

    private fun fetchEleven(text: String, key: String, voice: String): File {
        val url = URL("https://api.elevenlabs.io/v1/text-to-speech/$voice?output_format=mp3_44100_128")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("xi-api-key", key)
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "audio/mpeg")
            val body = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) throw RuntimeException("EL HTTP " + conn.responseCode)
            val f = File(ctx.cacheDir, "el_" + System.currentTimeMillis() + ".mp3")
            conn.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            return f
        } finally {
            conn.disconnect()
        }
    }

    private fun playFile(f: File, fallbackText: String) {
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener {
                try {
                    it.release()
                } catch (e: Exception) {
                }
                player = null
                f.delete()
                fire()
            }
            mp.setOnErrorListener { m, _, _ ->
                try {
                    m.release()
                } catch (e: Exception) {
                }
                player = null
                f.delete()
                speakTts(fallbackText)
                true
            }
            mp.prepare()
            player = mp
            mp.start()
        } catch (e: Exception) {
            f.delete()
            speakTts(fallbackText)
        }
    }

    fun stop() {
        generation++
        try {
            tts?.stop()
        } catch (e: Exception) {
        }
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
    }

    fun shutdown() {
        stop()
        pendingDone = null
        try {
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
    }
}
