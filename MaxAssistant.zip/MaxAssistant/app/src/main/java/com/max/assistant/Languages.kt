package com.max.assistant

import android.content.Context
import java.util.Locale

data class Lang(val code: String, val label: String, val english: String)

object Languages {
    val all = listOf(
        Lang("hi-IN", "हिन्दी / Hinglish", "Hindi (Devanagari; if the user speaks Hinglish, reply in simple Hindi)"),
        Lang("en-IN", "English (India)", "English"),
        Lang("pa-IN", "ਪੰਜਾਬੀ Punjabi", "Punjabi (Gurmukhi script)"),
        Lang("mr-IN", "मराठी Marathi", "Marathi (Devanagari script)"),
        Lang("gu-IN", "ગુજરાતી Gujarati", "Gujarati (Gujarati script)"),
        Lang("bn-IN", "বাংলা Bengali", "Bengali (Bengali script)"),
        Lang("ta-IN", "தமிழ் Tamil", "Tamil (Tamil script)"),
        Lang("te-IN", "తెలుగు Telugu", "Telugu (Telugu script)"),
        Lang("kn-IN", "ಕನ್ನಡ Kannada", "Kannada (Kannada script)"),
        Lang("ml-IN", "മലയാളം Malayalam", "Malayalam (Malayalam script)"),
        Lang("ur-IN", "اردو Urdu", "Urdu (Arabic script)"),
        Lang("or-IN", "ଓଡ଼ିଆ Odia", "Odia (Odia script)"),
        Lang("en-US", "English (US)", "English")
    )

    fun find(code: String): Lang = all.firstOrNull { it.code == code } ?: all[0]
    fun locale(code: String): Locale = Locale.forLanguageTag(code)
}

/** Small table of spoken UI strings in the main supported languages (others fall back to English). */
object T {
    private fun l(c: Context) = Prefs.lang(c).substringBefore("-")

    fun ack(c: Context): String = when (l(c)) {
        "hi" -> "जी?"
        "pa" -> "ਜੀ?"
        "mr" -> "हं, बोला?"
        "gu" -> "હા, બોલો?"
        "bn" -> "হ্যাঁ, বলুন?"
        else -> "Yes?"
    }

    fun askName(c: Context, n: String): String = when (l(c)) {
        "hi" -> "नमस्ते! मैं $n हूँ। आपका नाम क्या है?"
        "pa" -> "ਸਤ ਸ੍ਰੀ ਅਕਾਲ! ਮੈਂ $n ਹਾਂ। ਤੁਹਾਡਾ ਨਾਮ ਕੀ ਹੈ?"
        "mr" -> "नमस्कार! मी $n आहे. तुमचं नाव काय?"
        "gu" -> "નમસ્તે! હું $n છું. તમારું નામ શું છે?"
        "bn" -> "নমস্কার! আমি $n। আপনার নাম কী?"
        else -> "Hello! I'm $n. What's your name?"
    }

    fun ready(c: Context, n: String, u: String): String = when (l(c)) {
        "hi" -> "नमस्ते $u, मैं $n तैयार हूँ।"
        "pa" -> "ਸਤ ਸ੍ਰੀ ਅਕਾਲ $u, ਮੈਂ $n ਤਿਆਰ ਹਾਂ।"
        "mr" -> "नमस्कार $u, मी $n तयार आहे."
        "gu" -> "નમસ્તે $u, હું $n તૈયાર છું."
        "bn" -> "নমস্কার $u, আমি $n প্রস্তুত।"
        else -> "Hello $u, $n is ready."
    }

    fun noKey(c: Context): String = when (l(c)) {
        "hi" -> "पहले सेटिंग्स में Gemini API key डालिए।"
        "pa" -> "ਪਹਿਲਾਂ ਸੈਟਿੰਗਜ਼ ਵਿੱਚ Gemini API key ਪਾਓ।"
        "mr" -> "आधी सेटिंग्जमध्ये Gemini API key टाका."
        "gu" -> "પહેલા સેટિંગ્સમાં Gemini API key નાખો."
        "bn" -> "আগে সেটিংসে Gemini API key দিন।"
        else -> "Please add your Gemini API key in settings first."
    }

    fun netError(c: Context): String = when (l(c)) {
        "hi" -> "इंटरनेट या API में दिक्कत है।"
        "pa" -> "ਇੰਟਰਨੈੱਟ ਜਾਂ API ਵਿੱਚ ਦਿੱਕਤ ਹੈ।"
        "mr" -> "इंटरनेट किंवा API मध्ये अडचण आहे."
        "gu" -> "ઇન્ટરનેટ અથવા API માં સમસ્યા છે."
        "bn" -> "ইন্টারনেট বা API তে সমস্যা আছে।"
        else -> "There is a problem with the internet or the API."
    }

    fun callIn(c: Context, who: String): String = when (l(c)) {
        "hi" -> "$who का कॉल आ रहा है। उठाऊँ? हाँ बोलिए तो उठा लूँगा।"
        "pa" -> "$who ਦਾ ਕਾਲ ਆ ਰਿਹਾ ਹੈ। ਚੁੱਕਾਂ? ਹਾਂ ਕਹੋ ਤਾਂ ਚੁੱਕ ਲਵਾਂਗਾ।"
        "mr" -> "$who चा कॉल येत आहे. उचलू? हो म्हणा, मी उचलतो."
        "gu" -> "$who નો કૉલ આવી રહ્યો છે. ઉપાડું? હા કહો તો ઉપાડી લઈશ."
        "bn" -> "$who এর কল আসছে। ধরব? হ্যাঁ বললে ধরব।"
        else -> "Incoming call from $who. Should I answer? Say yes to pick up."
    }

    fun callAnswered(c: Context): String = when (l(c)) {
        "hi" -> "कॉल उठा लिया।"
        "pa" -> "ਕਾਲ ਚੁੱਕ ਲਿਆ।"
        "mr" -> "कॉल उचलला."
        "gu" -> "કૉલ ઉપાડી લીધો."
        "bn" -> "কল ধরেছি।"
        else -> "Call answered."
    }

    fun callRejected(c: Context): String = when (l(c)) {
        "hi" -> "कॉल काट दिया।"
        "pa" -> "ਕਾਲ ਕੱਟ ਦਿੱਤਾ।"
        "mr" -> "कॉल कट केला."
        "gu" -> "કૉલ કાપી નાખ્યો."
        "bn" -> "কল কেটে দিয়েছি।"
        else -> "Call rejected."
    }

    fun done(c: Context): String = when (l(c)) {
        "hi" -> "हो गया।"
        "pa" -> "ਹੋ ਗਿਆ।"
        "mr" -> "झालं."
        "gu" -> "થઈ ગયું."
        "bn" -> "হয়ে গেছে।"
        else -> "Done."
    }

    fun offline(c: Context): String = when (l(c)) {
        "hi" -> "इंटरनेट नहीं है, इसलिए अभी सिर्फ़ बेसिक कमांड चलेंगे।"
        "pa" -> "ਇੰਟਰਨੈੱਟ ਨਹੀਂ ਹੈ, ਇਸ ਲਈ ਸਿਰਫ਼ ਬੇਸਿਕ ਕਮਾਂਡ ਚੱਲਣਗੇ।"
        "mr" -> "इंटरनेट नाही, म्हणून फक्त बेसिक कमांड चालतील."
        "gu" -> "ઇન્ટરનેટ નથી, એટલે માત્ર બેઝિક કમાન્ડ ચાલશે."
        "bn" -> "ইন্টারনেট নেই, তাই শুধু বেসিক কমান্ড চলবে।"
        else -> "There is no internet, so only basic commands work right now."
    }

    fun agentFail(c: Context): String = when (l(c)) {
        "hi" -> "मैं यह काम पूरा नहीं कर पाया।"
        "pa" -> "ਮੈਂ ਇਹ ਕੰਮ ਪੂਰਾ ਨਹੀਂ ਕਰ ਸਕਿਆ।"
        "mr" -> "मला हे काम पूर्ण करता आले नाही."
        "gu" -> "હું આ કામ પૂરું કરી શક્યો નહીં."
        "bn" -> "আমি এই কাজটি শেষ করতে পারিনি।"
        else -> "I could not complete that task."
    }

    fun needAccessibility(c: Context): String = when (l(c)) {
        "hi" -> "इसके लिए Max की Accessibility सेटिंग चालू कीजिए।"
        "pa" -> "ਇਸ ਲਈ Accessibility ਚਾਲੂ ਕਰੋ।"
        "mr" -> "यासाठी Accessibility चालू करा."
        "gu" -> "આ માટે Accessibility ચાલુ કરો."
        "bn" -> "এর জন্য Accessibility চালু করুন।"
        else -> "Please turn on the Accessibility setting for this."
    }

    fun notFound(c: Context, who: String): String = when (l(c)) {
        "hi" -> "$who नाम का कॉन्टैक्ट नहीं मिला।"
        "pa" -> "$who ਨਾਮ ਦਾ ਸੰਪਰਕ ਨਹੀਂ ਮਿਲਿਆ।"
        "mr" -> "$who नावाचा संपर्क सापडला नाही."
        "gu" -> "$who નામનો સંપર્ક મળ્યો નથી."
        "bn" -> "$who নামের কন্টাক্ট পাওয়া যায়নি।"
        else -> "I could not find a contact named $who."
    }
}
