package com.max.assistant

import android.content.ContentValues
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/** Headless camera capture (no preview needed) used for selfies, intruder photos and scene analysis. */
class CameraHelper(private val ctx: Context) {

    fun capture(front: Boolean, cb: (ByteArray?) -> Unit) {
        val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val facing = if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
        var camId: String? = null
        var chars: CameraCharacteristics? = null
        try {
            for (cid in mgr.cameraIdList) {
                val ch = mgr.getCameraCharacteristics(cid)
                if (ch.get(CameraCharacteristics.LENS_FACING) == facing) {
                    camId = cid
                    chars = ch
                    break
                }
            }
        } catch (e: Exception) {
            cb(null)
            return
        }
        if (camId == null || chars == null) {
            cb(null)
            return
        }
        Job(mgr, camId, chars, cb).start()
    }

    private inner class Job(
        val mgr: CameraManager,
        val camId: String,
        val chars: CameraCharacteristics,
        val cb: (ByteArray?) -> Unit
    ) {
        private val done = AtomicBoolean(false)
        private val thread = HandlerThread("max-cam")
        private lateinit var handler: Handler
        private var camera: CameraDevice? = null
        private var session: CameraCaptureSession? = null
        private var jpegReader: ImageReader? = null
        private var yuvReader: ImageReader? = null

        fun start() {
            thread.start()
            handler = Handler(thread.looper)
            handler.postDelayed({ finish(null) }, 10000)
            try {
                val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val jpegSizes = map?.getOutputSizes(ImageFormat.JPEG)
                val yuvSizes = map?.getOutputSizes(ImageFormat.YUV_420_888)
                if (jpegSizes == null || jpegSizes.isEmpty() || yuvSizes == null || yuvSizes.isEmpty()) {
                    finish(null)
                    return
                }
                val js = jpegSizes.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height } ?: jpegSizes[0]
                val ys = yuvSizes.filter { it.width >= 480 }.minByOrNull { it.width * it.height } ?: yuvSizes[0]
                jpegReader = ImageReader.newInstance(js.width, js.height, ImageFormat.JPEG, 2)
                yuvReader = ImageReader.newInstance(ys.width, ys.height, ImageFormat.YUV_420_888, 2)
                yuvReader!!.setOnImageAvailableListener({ r ->
                    try {
                        r.acquireLatestImage()?.close()
                    } catch (e: Exception) {
                    }
                }, handler)
                jpegReader!!.setOnImageAvailableListener({ r ->
                    try {
                        val img = r.acquireLatestImage()
                        if (img != null) {
                            val buf = img.planes[0].buffer
                            val bytes = ByteArray(buf.remaining())
                            buf.get(bytes)
                            img.close()
                            finish(bytes)
                        }
                    } catch (e: Exception) {
                        finish(null)
                    }
                }, handler)
                mgr.openCamera(camId, object : CameraDevice.StateCallback() {
                    override fun onOpened(c: CameraDevice) {
                        camera = c
                        createSession(c)
                    }

                    override fun onDisconnected(c: CameraDevice) {
                        c.close()
                        finish(null)
                    }

                    override fun onError(c: CameraDevice, error: Int) {
                        c.close()
                        finish(null)
                    }
                }, handler)
            } catch (e: Exception) {
                finish(null)
            }
        }

        @Suppress("DEPRECATION")
        private fun createSession(c: CameraDevice) {
            try {
                val surfaces = listOf(yuvReader!!.surface, jpegReader!!.surface)
                c.createCaptureSession(surfaces, object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        session = s
                        try {
                            val req = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                            req.addTarget(yuvReader!!.surface)
                            req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                            req.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                            s.setRepeatingRequest(req.build(), null, handler)
                            handler.postDelayed({ shoot(c, s) }, 1500)
                        } catch (e: Exception) {
                            finish(null)
                        }
                    }

                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        finish(null)
                    }
                }, handler)
            } catch (e: Exception) {
                finish(null)
            }
        }

        private fun shoot(c: CameraDevice, s: CameraCaptureSession) {
            try {
                try {
                    s.stopRepeating()
                } catch (e: Exception) {
                }
                val req = c.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                req.addTarget(jpegReader!!.surface)
                req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                req.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                val orient = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
                req.set(CaptureRequest.JPEG_ORIENTATION, orient)
                req.set(CaptureRequest.JPEG_QUALITY, 85.toByte())
                s.capture(req.build(), null, handler)
            } catch (e: Exception) {
                finish(null)
            }
        }

        private fun finish(bytes: ByteArray?) {
            if (!done.compareAndSet(false, true)) return
            try {
                session?.close()
            } catch (e: Exception) {
            }
            try {
                camera?.close()
            } catch (e: Exception) {
            }
            try {
                jpegReader?.close()
            } catch (e: Exception) {
            }
            try {
                yuvReader?.close()
            } catch (e: Exception) {
            }
            try {
                thread.quitSafely()
            } catch (e: Exception) {
            }
            cb(bytes)
        }
    }

    /** Saves a JPEG to the gallery (Pictures/Max). Returns a short description of where it went. */
    fun save(bytes: ByteArray, prefix: String): String? {
        val name = prefix + "_" + System.currentTimeMillis() + ".jpg"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Max")
                val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                if (uri != null) {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    "Pictures/Max/$name"
                } else null
            } else {
                val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: ctx.filesDir
                val f = File(dir, name)
                f.writeBytes(bytes)
                f.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }
}
