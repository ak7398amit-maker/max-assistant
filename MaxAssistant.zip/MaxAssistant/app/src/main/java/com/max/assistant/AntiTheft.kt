package com.max.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Motion + charger-disconnect guard with a loud siren. */
class AntiTheft(private val ctx: Context, private val onTriggered: (String) -> Unit) : SensorEventListener {
    private val main = Handler(Looper.getMainLooper())
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var armedAt = 0L
    private var hits = 0
    private var wasCharging = false
    private var powerReceiver: BroadcastReceiver? = null

    @Volatile
    var armed = false
        private set

    @Volatile
    var sounding = false
        private set

    @Volatile
    private var sirenThread: Thread? = null

    fun arm() {
        if (armed) return
        armed = true
        armedAt = System.currentTimeMillis()
        hits = 0
        Prefs.putBool(ctx, Prefs.K_ANTITHEFT, true)
        val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
        val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        wasCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (armed && wasCharging && System.currentTimeMillis() - armedAt > 3000) {
                    trigger("charger")
                }
            }
        }
        powerReceiver = r
        ctx.registerReceiver(r, IntentFilter(Intent.ACTION_POWER_DISCONNECTED))
    }

    fun disarm() {
        Prefs.putBool(ctx, Prefs.K_ANTITHEFT, false)
        disarmKeepFlag()
    }

    /** Stops sensors/receivers but keeps the saved "armed" setting (used when the service itself stops). */
    fun disarmKeepFlag() {
        armed = false
        try {
            sm.unregisterListener(this)
        } catch (e: Exception) {
        }
        try {
            powerReceiver?.let { ctx.unregisterReceiver(it) }
        } catch (e: Exception) {
        }
        powerReceiver = null
        stopSiren()
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (!armed || sounding) return
        if (System.currentTimeMillis() - armedAt < 6000) return
        val mag = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        if (abs(mag - 9.81f) > 2.2f) {
            hits++
            if (hits >= 6) trigger("motion")
        } else if (hits > 0 && Math.random() < 0.05) {
            hits--
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    fun trigger(reason: String) {
        if (sounding) return
        hits = 0
        onTriggered(reason)
        startSiren()
    }

    fun startSiren() {
        if (sounding) return
        sounding = true
        UiBus.siren(true)
        UiBus.state(HudState.ALERT)
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        } catch (e: Exception) {
        }
        val t = Thread {
            var track: AudioTrack? = null
            try {
                val sr = 22050
                val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(max(minBuf, 8192))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track.play()
                val chunk = ShortArray(2048)
                var phase = 0.0
                var n = 0L
                val startMs = System.currentTimeMillis()
                while (sounding && System.currentTimeMillis() - startMs < 180000) {
                    for (i in chunk.indices) {
                        val tt = n.toDouble() / sr
                        val f = 1100.0 + 500.0 * sin(2.0 * Math.PI * 1.5 * tt)
                        phase += 2.0 * Math.PI * f / sr
                        chunk[i] = (sin(phase) * 30000.0).toInt().toShort()
                        n++
                    }
                    track.write(chunk, 0, chunk.size)
                }
            } catch (e: Exception) {
            } finally {
                try {
                    track?.stop()
                } catch (e: Exception) {
                }
                try {
                    track?.release()
                } catch (e: Exception) {
                }
                sounding = false
                main.post {
                    UiBus.siren(false)
                    UiBus.state(HudState.IDLE)
                }
            }
        }
        sirenThread = t
        t.start()
    }

    fun stopSiren() {
        sounding = false
    }
}
