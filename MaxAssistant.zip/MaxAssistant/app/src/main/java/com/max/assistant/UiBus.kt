package com.max.assistant

enum class HudState { OFF, IDLE, LISTENING, THINKING, SPEAKING, ALERT }

object UiBus {
    interface Listener {
        fun onState(s: HudState)
        fun onHeard(t: String)
        fun onReply(t: String)
        fun onSiren(on: Boolean)
    }

    @Volatile
    var listener: Listener? = null

    @Volatile
    var state: HudState = HudState.OFF

    @Volatile
    var sirenOn: Boolean = false

    fun state(s: HudState) {
        state = s
        listener?.onState(s)
    }

    fun heard(t: String) {
        listener?.onHeard(t)
    }

    fun reply(t: String) {
        listener?.onReply(t)
    }

    fun siren(on: Boolean) {
        sirenOn = on
        listener?.onSiren(on)
    }
}
