package com.max.assistant

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    class Turn(val role: String, val text: String)

    /** Blocking call. Run on a background thread. */
    fun generate(
        ctx: Context,
        system: String,
        history: List<Turn>,
        userText: String,
        imageJpeg: ByteArray?,
        json: Boolean
    ): String {
        val key = Prefs.get(ctx, Prefs.K_API).trim()
        if (key.isEmpty()) throw IllegalStateException("NO_KEY")
        val model = Prefs.get(ctx, Prefs.K_MODEL, Prefs.DEFAULT_MODEL).trim().ifBlank { Prefs.DEFAULT_MODEL }

        val contents = JSONArray()
        for (t in history) {
            contents.put(
                JSONObject().put("role", t.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", t.text)))
            )
        }
        val parts = JSONArray().put(JSONObject().put("text", userText))
        if (imageJpeg != null) {
            parts.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject().put("mimeType", "image/jpeg")
                        .put("data", Base64.encodeToString(imageJpeg, Base64.NO_WRAP))
                )
            )
        }
        contents.put(JSONObject().put("role", "user").put("parts", parts))

        val gen = JSONObject().put("temperature", 0.6)
        if (json) gen.put("responseMimeType", "application/json")
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", gen)

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException("HTTP $code: " + text.take(300))
            val root = JSONObject(text)
            val cand = root.getJSONArray("candidates").getJSONObject(0)
            val ps = cand.getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text", ""))
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }
}
