package com.max.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream

/** Gives Max eyes and hands on the screen: read text, click by text, scroll, type, screenshot. */
class MaxAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MaxAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun roots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                val r = w.root
                if (r != null) out.add(r)
            }
        } catch (e: Exception) {
        }
        if (out.isEmpty()) {
            val r = rootInActiveWindow
            if (r != null) out.add(r)
        }
        return out
    }

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null || depth > 40) return
        f(n)
        for (i in 0 until n.childCount) {
            val c = try {
                n.getChild(i)
            } catch (e: Exception) {
                null
            }
            walk(c, depth + 1, f)
        }
    }

    /** All visible text on screen, top to bottom. */
    fun readScreen(): String {
        val sb = StringBuilder()
        for (r in roots()) {
            walk(r, 0) { n ->
                val t = n.text?.toString()?.trim().orEmpty()
                val d = n.contentDescription?.toString()?.trim().orEmpty()
                if (t.isNotEmpty()) sb.append(t).append('\n')
                else if (d.isNotEmpty()) sb.append(d).append('\n')
            }
            if (sb.length > 8000) break
        }
        return sb.toString().take(8000)
    }

    private fun matchNodes(target: String, ids: List<String>): List<AccessibilityNodeInfo> {
        val exact = ArrayList<AccessibilityNodeInfo>()
        val part = ArrayList<AccessibilityNodeInfo>()
        val t = target.trim().lowercase()
        for (r in roots()) {
            for (id in ids) {
                try {
                    exact.addAll(r.findAccessibilityNodeInfosByViewId(id))
                } catch (e: Exception) {
                }
            }
            if (t.isNotEmpty()) {
                walk(r, 0) { n ->
                    val a = n.text?.toString()?.trim()?.lowercase().orEmpty()
                    val b = n.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
                    if (a == t || b == t) exact.add(n)
                    else if ((a.isNotEmpty() && a.contains(t)) || (b.isNotEmpty() && b.contains(t))) part.add(n)
                }
            }
        }
        return exact + part.sortedBy { (it.text?.length ?: it.contentDescription?.length ?: 0) }
    }

    fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var up = 0
        while (cur != null && up < 7) {
            if (cur.isClickable && cur.isEnabled) {
                if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            cur = cur.parent
            up++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.width() > 0 && r.height() > 0) {
            return tap(r.exactCenterX(), r.exactCenterY())
        }
        return false
    }

    fun clickText(text: String): Boolean {
        for (n in matchNodes(text, emptyList())) {
            if (clickNode(n)) return true
        }
        return false
    }

    /** Waits (up to timeoutMs) for a node by text/view id to appear, then clicks it. */
    fun clickWhenAvailable(texts: List<String>, ids: List<String>, timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            var first = true
            for (t in texts) {
                val nodes = matchNodes(t, if (first) ids else emptyList())
                first = false
                for (n in nodes) {
                    if (clickNode(n)) return true
                }
            }
            if (texts.isEmpty()) {
                for (n in matchNodes("", ids)) if (clickNode(n)) return true
            }
            try {
                Thread.sleep(500)
            } catch (e: InterruptedException) {
                return false
            }
        }
        return false
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, dur))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun scroll(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (direction.lowercase()) {
            "up" -> swipe(w / 2, h * 0.30f, w / 2, h * 0.75f, 350)
            "left" -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2, 300)
            "right" -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2, 300)
            else -> swipe(w / 2, h * 0.75f, w / 2, h * 0.30f, 350)
        }
    }

    fun typeText(text: String): Boolean {
        for (r in roots()) {
            var target: AccessibilityNodeInfo? = null
            try {
                target = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            } catch (e: Exception) {
            }
            if (target == null) {
                walk(r, 0) { n -> if (target == null && n.isEditable) target = n }
            }
            val t = target
            if (t != null) {
                val b = Bundle()
                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                return t.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
            }
        }
        return false
    }


    // ------------------------------------------------------------ screen snapshot for the agent

    class SNode(
        val idx: Int,
        val label: String,
        val kind: String,
        val clickable: Boolean,
        val editable: Boolean,
        val scrollable: Boolean,
        val state: String,
        val ref: AccessibilityNodeInfo
    )

    @Volatile
    var lastNodes: List<SNode> = emptyList()

    fun snapshot(max: Int): List<SNode> {
        val out = ArrayList<SNode>()
        for (r in roots()) {
            walk(r, 0) { n ->
                if (out.size < max && n.isVisibleToUser) {
                    val text = n.text?.toString()?.trim().orEmpty()
                    val desc = n.contentDescription?.toString()?.trim().orEmpty()
                    var label = if (text.isNotEmpty()) text else desc
                    if (label.isEmpty()) label = n.hintText?.toString()?.trim().orEmpty()
                    val keep = label.isNotEmpty() || n.isEditable || n.isCheckable
                    if (keep) {
                        var st = ""
                        if (Build.VERSION.SDK_INT >= 30) st = n.stateDescription?.toString().orEmpty()
                        if (n.isCheckable) st = (st + (if (n.isChecked) " checked" else " unchecked")).trim()
                        val kind = n.className?.toString()?.substringAfterLast('.').orEmpty()
                        out.add(SNode(out.size, label.take(80), kind, n.isClickable, n.isEditable, n.isScrollable, st, n))
                    }
                }
            }
        }
        lastNodes = out
        return out
    }

    fun clickIndex(i: Int): Boolean {
        val n = lastNodes.getOrNull(i) ?: return false
        return clickNode(n.ref)
    }

    fun longClickIndex(i: Int): Boolean {
        val n = lastNodes.getOrNull(i) ?: return false
        return n.ref.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
    }

    fun setTextIndex(i: Int, text: String): Boolean {
        val n = lastNodes.getOrNull(i)?.ref ?: return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun imeEnter(i: Int): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val n = lastNodes.getOrNull(i)?.ref ?: return false
        return n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    /** Text, description and on/off state of the first element that mentions any of the labels (used for quick-settings tiles). */
    fun tileInfo(labels: List<String>): String? {
        for (r in roots()) {
            var found: String? = null
            walk(r, 0) { n ->
                if (found == null) {
                    val low = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()
                    if (labels.any { low.contains(it) }) {
                        val sb = StringBuilder()
                        var cur: AccessibilityNodeInfo? = n
                        var up = 0
                        while (cur != null && up < 3) {
                            sb.append(cur.text ?: "").append(' ').append(cur.contentDescription ?: "").append(' ')
                            if (Build.VERSION.SDK_INT >= 30) sb.append(cur.stateDescription ?: "").append(' ')
                            if (cur.isCheckable) sb.append(if (cur.isChecked) "checked " else "unchecked ")
                            cur = cur.parent
                            up++
                        }
                        found = sb.toString().lowercase()
                    }
                }
            }
            val f = found
            if (f != null) return f
        }
        return null
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    /** Screenshot as a downscaled JPEG (Android 11+). */
    fun screenshot(cb: (ByteArray?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) {
            cb(null)
            return
        }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    try {
                        val hb = result.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                        if (soft == null) {
                            cb(null)
                            return
                        }
                        val maxSide = 1600f
                        val scale = minOf(1f, maxSide / maxOf(soft.width, soft.height).toFloat())
                        val scaled = if (scale < 1f) Bitmap.createScaledBitmap(
                            soft, (soft.width * scale).toInt(), (soft.height * scale).toInt(), true
                        ) else soft
                        val bos = ByteArrayOutputStream()
                        scaled.compress(Bitmap.CompressFormat.JPEG, 88, bos)
                        cb(bos.toByteArray())
                    } catch (e: Exception) {
                        cb(null)
                    }
                }

                override fun onFailure(errorCode: Int) {
                    cb(null)
                }
            })
        } catch (e: Exception) {
            cb(null)
        }
    }
}
