package com.max.assistant

import android.content.Context

object Wake {
    fun words(ctx: Context): List<String> {
        val l = ArrayList<String>()
        l.add(Prefs.assistantName(ctx).lowercase())
        Prefs.get(ctx, Prefs.K_ALIASES, Prefs.DEFAULT_ALIASES).split(",")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .forEach { if (!l.contains(it)) l.add(it) }
        if (Prefs.assistantName(ctx).equals("max", ignoreCase = true)) {
            for (x in listOf("मैक्स", "मैक", "मेक्स", "मेक", "मॅक्स", "मैंक्स", "मैक्स्", "mac", "macs", "mack", "makes", "maks", "mex", "ਮੈਕਸ", "મેક્સ", "ম্যাক্স")) {
                if (!l.contains(x)) l.add(x)
            }
        }
        return l
    }

    private fun isAsciiLetter(ch: Char) = ch in 'a'..'z' || ch in 'A'..'Z'

    private fun isAsciiWord(w: String) = w.isNotEmpty() && w.all { isAsciiLetter(it) }

    /** Returns the text spoken after the wake word ("" if only the wake word), or null if no wake word was heard. */
    fun extract(candidates: List<String>, words: List<String>): String? {
        for (c in candidates) {
            val low = c.lowercase()
            for (w in words) {
                var from = 0
                while (true) {
                    val i = low.indexOf(w, from)
                    if (i < 0) break
                    val end = i + w.length
                    var ok = true
                    if (isAsciiWord(w)) {
                        if (i > 0 && isAsciiLetter(low[i - 1])) ok = false
                        if (end < low.length && isAsciiLetter(low[end])) ok = false
                    }
                    if (ok) return clean(low.substring(end))
                    from = i + 1
                }
            }
        }
        // fuzzy match for longer Latin names (speech engines often mishear by one letter)
        for (c in candidates) {
            val low = c.lowercase()
            val tokens = low.split(Regex("[\\s,.!?]+")).filter { it.isNotEmpty() }
            for ((idx, t) in tokens.withIndex()) {
                for (w in words) {
                    if (isAsciiWord(w) && w.length >= 3 && t.length >= 3 && t[0] == w[0] && lev(t, w) <= 1) {
                        return clean(tokens.drop(idx + 1).joinToString(" "))
                    }
                }
            }
        }
        return null
    }

    private fun clean(s: String): String = s.trim(' ', ',', '.', '!', '?', '-', '।')

    private fun lev(a: String, b: String): Int {
        if (kotlin.math.abs(a.length - b.length) > 1) return 2
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
        }
        return dp[a.length][b.length]
    }
}
