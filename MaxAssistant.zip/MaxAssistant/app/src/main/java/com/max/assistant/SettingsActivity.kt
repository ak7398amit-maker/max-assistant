package com.max.assistant

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private lateinit var box: LinearLayout
    private val fields = HashMap<String, EditText>()
    private lateinit var langSpinner: Spinner
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun header(t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.parseColor("#00E5FF"))
        tv.textSize = 15f
        tv.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        tv.setPadding(0, dp(22), 0, dp(6))
        box.addView(tv)
    }

    private fun hint(t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.parseColor("#7F93A6"))
        tv.textSize = 12f
        tv.setPadding(0, 0, 0, dp(4))
        box.addView(tv)
    }

    private fun field(key: String, label: String, value: String, secret: Boolean = false, number: Boolean = false) {
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 13f
        box.addView(tv)
        val et = EditText(this)
        et.setText(value)
        et.setTextColor(Color.WHITE)
        et.setHintTextColor(Color.GRAY)
        et.textSize = 14f
        et.setSingleLine(true)
        if (secret) et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        if (number) et.inputType = InputType.TYPE_CLASS_PHONE
        box.addView(et)
        fields[key] = et
    }

    private fun button(label: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        box.addView(b)
    }

    private fun switch(label: String, key: String, def: Boolean) {
        val s = Switch(this)
        s.text = label
        s.setTextColor(Color.WHITE)
        s.isChecked = Prefs.getBool(this, key, def)
        s.setOnCheckedChangeListener { _, v -> Prefs.putBool(this, key, v) }
        s.setPadding(0, dp(8), 0, dp(8))
        box.addView(s)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#050B14"))
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(36), dp(18), dp(40))
        sv.addView(box)
        setContentView(sv)

        header("◉ ASSISTANT")
        field(Prefs.K_NAME, "Assistant ka naam (wake word) — kuch bhi rakh sakte ho", Prefs.assistantName(this))
        hint("Naam badalne ke baad niche 'Extra wake spellings' me uska Hindi/Punjabi spelling bhi daalo (jaise: मैक्स, ਮੈਕਸ) taaki sahi se sune.")
        field(Prefs.K_ALIASES, "Extra wake spellings (comma se alag)", Prefs.get(this, Prefs.K_ALIASES, Prefs.DEFAULT_ALIASES))
        field(Prefs.K_USER, "Aapka naam", Prefs.userName(this))

        val lt = TextView(this)
        lt.text = "Bhasha (Language)"
        lt.setTextColor(Color.WHITE)
        lt.textSize = 13f
        lt.setPadding(0, dp(10), 0, 0)
        box.addView(lt)
        langSpinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Languages.all.map { it.label })
        langSpinner.adapter = adapter
        langSpinner.setSelection(Languages.all.indexOfFirst { it.code == Prefs.lang(this) }.coerceAtLeast(0))
        box.addView(langSpinner)
        hint("Bolte waqt jo bhasha chuni hai wahi suni jayegi. Aap kisi aur bhasha me bhi bol sakte ho — Max usi me jawab dega, ya bol do 'Punjabi me bolo'.")

        header("◉ GEMINI (DIMAAG)")
        field(Prefs.K_API, "Gemini API key (aistudio.google.com se free)", Prefs.get(this, Prefs.K_API), secret = true)
        field(Prefs.K_MODEL, "Model", Prefs.get(this, Prefs.K_MODEL, Prefs.DEFAULT_MODEL))

        button("Gemini test karo") {
            save()
            Toast.makeText(this, "Test chal raha hai...", Toast.LENGTH_SHORT).show()
            Thread {
                val res = try {
                    val r = GeminiClient.generate(this, "Reply with one short word.", emptyList(), "Say OK", null, false)
                    "OK ✅ " + r.trim().take(40)
                } catch (e: Exception) {
                    if (e is GeminiError) "❌ HTTP ${e.code}: ${e.message}" else "❌ " + e.javaClass.simpleName + ": " + (e.message ?: "")
                }
                runOnUiThread { android.app.AlertDialog.Builder(this).setTitle("Gemini test").setMessage(res).setPositiveButton("OK", null).show() }
            }.start()
        }

        header("◉ AWAAZ (OPTIONAL: ELEVENLABS)")
        hint("Khali chhodo to phone ki apni awaaz use hogi. ElevenLabs key + Voice ID daalo to uski awaaz aayegi.")
        field(Prefs.K_EL_KEY, "ElevenLabs API key", Prefs.get(this, Prefs.K_EL_KEY), secret = true)
        field(Prefs.K_EL_VOICE, "ElevenLabs Voice ID", Prefs.get(this, Prefs.K_EL_VOICE))

        header("◉ EMERGENCY / WHATSAPP")
        field(Prefs.K_SOS, "SOS numbers (comma se alag, +91 ke saath)", Prefs.get(this, Prefs.K_SOS), number = true)
        field(Prefs.K_CC, "Country code (WhatsApp ke liye)", Prefs.get(this, Prefs.K_CC, "91"), number = true)

        header("◉ OPTIONS")
        switch("Incoming call announce karo (haan bolne par uthao)", Prefs.K_ANNOUNCE_CALLS, true)
        switch("Galat unlock par intruder selfie", Prefs.K_THEFT_SELFIE, true)
        switch("Listening beep band rakho", Prefs.K_SILENT_BEEP, true)

        header("◉ PERMISSIONS (ek baar ON karo)")
        status = TextView(this)
        status.setTextColor(Color.parseColor("#FFC400"))
        status.textSize = 13f
        box.addView(status)
        button("1. Accessibility ON karo (click, scroll, WhatsApp send, screenshot)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("2. Notification access ON karo (messages padhne ke liye)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("3. Device admin ON karo (galat PIN par intruder selfie)") {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Sirf galat unlock attempt pata karne ke liye.")
            startActivity(i)
        }
        button("4. 'Display over other apps' ON karo (background me app kholne ke liye)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("5. Battery optimisation band karo (background me chalte rehne ke liye)") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button("6. Brightness control permission (optional)") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        button("Memory saaf karo (Max ne jo yaad rakha)") {
            Memory.clear(this)
            Toast.makeText(this, "Memory saaf ho gayi", Toast.LENGTH_SHORT).show()
        }
        hint("Saved hone ke baad Max ko STOP karke dobara START karo.")
    }

    override fun onResume() {
        super.onResume()
        val acc = MaxAccessibilityService.instance != null
        val ns = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))
        val overlay = Settings.canDrawOverlays(this)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val batt = pm.isIgnoringBatteryOptimizations(packageName)
        fun m(b: Boolean) = if (b) "✅" else "❌"
        status.text = "${m(acc)} Accessibility   ${m(ns)} Notification   ${m(admin)} Admin   ${m(overlay)} Overlay   ${m(batt)} Battery"
    }

    override fun onPause() {
        super.onPause()
        save()
    }

    private fun save() {
        val oldName = Prefs.assistantName(this)
        for ((k, v) in fields) {
            val t = v.text.toString().trim()
            if (k == Prefs.K_NAME && t.isEmpty()) continue
            Prefs.put(this, k, t)
        }
        if (Prefs.assistantName(this) != oldName && fields[Prefs.K_ALIASES]?.text.toString() == Prefs.DEFAULT_ALIASES) {
            Prefs.put(this, Prefs.K_ALIASES, "")
        }
        val idx = langSpinner.selectedItemPosition
        if (idx in Languages.all.indices) Prefs.put(this, Prefs.K_LANG, Languages.all[idx].code)
    }
}
