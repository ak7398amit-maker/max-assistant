package com.max.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), UiBus.Listener {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var hud: HudView
    private lateinit var title: TextView
    private lateinit var heard: TextView
    private lateinit var reply: TextView
    private lateinit var setup: TextView
    private lateinit var startBtn: Button
    private lateinit var talkBtn: Button
    private lateinit var theftBtn: Button
    private lateinit var sirenBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun styled(b: Button, color: Int) {
        val g = GradientDrawable()
        g.setStroke(dp(2), color)
        g.setColor(Color.argb(40, Color.red(color), Color.green(color), Color.blue(color)))
        g.cornerRadius = dp(14).toFloat()
        b.background = g
        b.setTextColor(color)
        b.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        b.textSize = 13f
        b.isAllCaps = true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#050B14"))
        root.setPadding(dp(16), dp(36), dp(16), dp(16))

        title = TextView(this)
        title.setTextColor(Color.parseColor("#00E5FF"))
        title.textSize = 18f
        title.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        title.gravity = Gravity.CENTER
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        setup = TextView(this)
        setup.setTextColor(Color.parseColor("#FFC400"))
        setup.textSize = 12f
        setup.gravity = Gravity.CENTER
        setup.setPadding(0, dp(6), 0, 0)
        root.addView(setup, LinearLayout.LayoutParams(-1, -2))

        hud = HudView(this)
        root.addView(hud, LinearLayout.LayoutParams(-1, 0, 1f))

        heard = TextView(this)
        heard.setTextColor(Color.parseColor("#7FD6E8"))
        heard.textSize = 14f
        heard.gravity = Gravity.CENTER
        heard.minLines = 2
        root.addView(heard, LinearLayout.LayoutParams(-1, -2))

        reply = TextView(this)
        reply.setTextColor(Color.WHITE)
        reply.textSize = 16f
        reply.gravity = Gravity.CENTER
        reply.minLines = 3
        reply.maxLines = 6
        reply.setPadding(0, dp(6), 0, dp(10))
        root.addView(reply, LinearLayout.LayoutParams(-1, -2))

        sirenBtn = Button(this)
        sirenBtn.text = "STOP SIREN"
        styled(sirenBtn, Color.parseColor("#FF1744"))
        sirenBtn.visibility = View.GONE
        sirenBtn.setOnClickListener { sendToService(VoiceService.ACTION_SIREN_OFF) }
        root.addView(sirenBtn, LinearLayout.LayoutParams(-1, dp(52)))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        startBtn = Button(this)
        talkBtn = Button(this)
        theftBtn = Button(this)
        val settings = Button(this)
        settings.text = "⚙"
        talkBtn.text = "🎤 TALK"
        styled(startBtn, Color.parseColor("#00E676"))
        styled(talkBtn, Color.parseColor("#00E5FF"))
        styled(theftBtn, Color.parseColor("#FFC400"))
        styled(settings, Color.parseColor("#7FD6E8"))
        val lp = { w: Float -> LinearLayout.LayoutParams(0, dp(52), w).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) } }
        row.addView(startBtn, lp(1.4f))
        row.addView(talkBtn, lp(1.2f))
        row.addView(theftBtn, lp(1.4f))
        row.addView(settings, lp(0.7f))
        root.addView(row, LinearLayout.LayoutParams(-1, -2))

        startBtn.setOnClickListener {
            if (VoiceService.running) {
                sendToService(VoiceService.ACTION_STOP)
            } else {
                startAssistant()
            }
        }
        talkBtn.setOnClickListener {
            if (!VoiceService.running) startAssistant() else sendToService(VoiceService.ACTION_TALK)
        }
        theftBtn.setOnClickListener {
            if (!VoiceService.running) {
                Toast.makeText(this, "Pehle assistant START karo", Toast.LENGTH_SHORT).show()
            } else sendToService(VoiceService.ACTION_ANTITHEFT_TOGGLE)
            ui.postDelayed({ refresh() }, 400)
        }
        settings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        UiBus.listener = this
        refresh()
        if (Prefs.get(this, Prefs.K_API).isBlank() && !shownSetup) {
            shownSetup = true
            Toast.makeText(this, "Pehle Settings me Gemini API key daalo", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private var shownSetup = false

    override fun onPause() {
        super.onPause()
        if (UiBus.listener === this) UiBus.listener = null
    }

    private fun refresh() {
        val name = Prefs.assistantName(this)
        title.text = "◉ " + name.uppercase() + " · VOICE ASSISTANT"
        hud.title = name
        hud.state = if (VoiceService.running) UiBus.state.let { if (it == HudState.OFF) HudState.IDLE else it } else HudState.OFF
        startBtn.text = if (VoiceService.running) "■ STOP" else "▶ START"
        theftBtn.text = if (Prefs.getBool(this, Prefs.K_ANTITHEFT, false) && VoiceService.running) "🛡 ON" else "🛡 THEFT"
        sirenBtn.visibility = if (UiBus.sirenOn) View.VISIBLE else View.GONE
        val missing = ArrayList<String>()
        if (MaxAccessibilityService.instance == null) missing.add("Accessibility")
        if (!notifAccess()) missing.add("Notification access")
        setup.text = if (missing.isEmpty()) "" else "Settings me ON karo: " + missing.joinToString(", ")
    }

    private fun notifAccess(): Boolean {
        val s = android.provider.Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(packageName)
    }

    private fun sendToService(action: String) {
        try {
            val i = Intent(this, VoiceService::class.java)
            i.action = action
            startService(i)
        } catch (e: Exception) {
        }
    }

    private val perms: Array<String> by lazy {
        val l = arrayListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
            Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) l.add(Manifest.permission.BLUETOOTH_CONNECT)
        l.toTypedArray()
    }

    private fun startAssistant() {
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 7)
            return
        }
        launchService()
    }

    private fun launchService() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mic permission zaroori hai", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val i = Intent(this, VoiceService::class.java)
            i.action = VoiceService.ACTION_START
            startForegroundService(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Start nahi ho paya: " + e.message, Toast.LENGTH_LONG).show()
        }
        ui.postDelayed({ refresh() }, 600)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) launchService()
    }

    // ---- UiBus
    override fun onState(s: HudState) {
        ui.post { refresh() }
    }

    override fun onHeard(t: String) {
        ui.post { heard.text = "🎤  $t" }
    }

    override fun onReply(t: String) {
        ui.post { reply.text = t }
    }

    override fun onSiren(on: Boolean) {
        ui.post { refresh() }
    }
}
