package com.max.assistant

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings

/** On/off switches and system settings: Wi-Fi, Bluetooth, mobile data, airplane, hotspot, DND, rotation... */
object Toggles {

    private val labels = mapOf(
        "wifi" to listOf("wi-fi", "wifi", "वाई-फाई", "वाईफाई", "वाई फाई", "internet", "इंटरनेट"),
        "bluetooth" to listOf("bluetooth", "ब्लूटूथ"),
        "data" to listOf("mobile data", "cellular data", "मोबाइल डेटा", "मोबाइल data", "data", "डेटा"),
        "airplane" to listOf("airplane", "flight mode", "aeroplane", "एयरप्लेन", "फ्लाइट मोड", "विमान"),
        "hotspot" to listOf("hotspot", "tethering", "हॉटस्पॉट"),
        "location" to listOf("location", "gps", "लोकेशन"),
        "dnd" to listOf("do not disturb", "dnd", "डू नॉट डिस्टर्ब"),
        "rotate" to listOf("auto-rotate", "auto rotate", "rotation", "ऑटो रोटेट", "ऑटो-रोटेट"),
        "nfc" to listOf("nfc"),
        "battery_saver" to listOf("battery saver", "power saving", "बैटरी सेवर"),
        "dark" to listOf("dark mode", "dark theme", "डार्क मोड")
    )

    fun canonical(what: String): String {
        val w = what.lowercase().replace("-", "").replace(" ", "")
        return when {
            w.contains("wifi") || w.contains("वाईफाई") || w.contains("वाइफाइ") -> "wifi"
            w.contains("bluetooth") || w.contains("ब्लूटूथ") -> "bluetooth"
            w.contains("data") || w.contains("डेटा") || w.contains("mobilenet") -> "data"
            w.contains("airplane") || w.contains("flight") || w.contains("aeroplane") || w.contains("एयरप्लेन") || w.contains("फ्लाइट") -> "airplane"
            w.contains("hotspot") || w.contains("tether") || w.contains("हॉटस्पॉट") -> "hotspot"
            w.contains("location") || w.contains("gps") || w.contains("लोकेशन") -> "location"
            w.contains("disturb") || w.contains("dnd") -> "dnd"
            w.contains("rotat") || w.contains("रोटेट") -> "rotate"
            w.contains("nfc") -> "nfc"
            w.contains("batterysaver") || w.contains("powersaving") -> "battery_saver"
            w.contains("dark") || w.contains("डार्क") -> "dark"
            else -> w
        }
    }

    @Suppress("DEPRECATION")
    private fun apiState(ctx: Context, key: String): Boolean? {
        return try {
            when (key) {
                "wifi" -> (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
                "bluetooth" -> BluetoothAdapter.getDefaultAdapter()?.isEnabled
                "airplane" -> Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
                "location" -> (ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager).isLocationEnabled
                "dnd" -> (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).currentInterruptionFilter !=
                    NotificationManager.INTERRUPTION_FILTER_ALL
                "rotate" -> Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseState(info: String): Boolean? {
        val t = info.split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.isNotEmpty() }
        if (t.contains("unchecked") || t.contains("off") || t.contains("बंद") || t.contains("बन्द")) return false
        if (t.contains("checked") || t.contains("on") || t.contains("चालू")) return true
        return null
    }

    private fun sleep(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    /** Returns null on success, or a message to speak. */
    fun set(ctx: Context, what: String, on: Boolean): String? {
        val key = canonical(what)
        if (key == "dnd" || key == "rotate") {
            val r = systemSetting(ctx, key, if (on) "on" else "off")
            if (r == null || key == "dnd") return r
        }
        val cur = apiState(ctx, key)
        if (cur != null && cur == on) return null
        val ls = labels[key] ?: return "$what ko main badal nahi sakta."
        val acc = MaxAccessibilityService.instance ?: return panel(ctx, key, T.needAccessibility(ctx))

        Actions.wakeScreen(ctx)
        acc.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        sleep(1200)
        var done = false
        for (attempt in 0 until 3) {
            val info = acc.tileInfo(ls)
            if (info != null) {
                val st = parseState(info)
                if (st != null && st == on) {
                    done = true
                } else {
                    for (l in ls) {
                        if (acc.clickText(l)) {
                            done = true
                            break
                        }
                    }
                }
                if (done) break
            }
            val dm = ctx.resources.displayMetrics
            val w = dm.widthPixels.toFloat()
            val h = dm.heightPixels.toFloat()
            if (attempt == 0) acc.swipe(w / 2, h * 0.12f, w / 2, h * 0.75f, 300) else acc.scroll("right")
            sleep(800)
        }
        sleep(900)
        acc.global(AccessibilityService.GLOBAL_ACTION_BACK)
        sleep(300)
        if (!done) return panel(ctx, key, "Quick settings me ${what} nahi mila.")
        val after = apiState(ctx, key)
        if (after != null && after != on) return panel(ctx, key, "${what} badal nahi paya.")
        return null
    }

    private fun panel(ctx: Context, key: String, msg: String): String {
        val i = when (key) {
            "wifi", "data" -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "airplane" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            "hotspot" -> Intent("android.settings.TETHER_SETTINGS")
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "nfc" -> Intent(Settings.ACTION_NFC_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        Actions.launch(ctx, i)
        return "$msg Maine settings khol di hain."
    }

    // ---------------------------------------------------------------- system settings

    fun systemSetting(ctx: Context, name: String, value: String): String? {
        val v = value.lowercase().trim()
        val on = v == "on" || v == "true" || v == "1" || v == "yes"
        try {
            when (canonical(name)) {
                "ringer" -> {}
                "dnd" -> {
                    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    if (!nm.isNotificationPolicyAccessGranted) {
                        Actions.launch(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                        return "Do Not Disturb ki permission do, phir dobara bolo."
                    }
                    nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
                    return null
                }
                "rotate" -> {
                    if (!Settings.System.canWrite(ctx)) return needWrite(ctx)
                    Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 1 else 0)
                    return null
                }
            }
            val n = name.lowercase()
            if (n.contains("ringer") || n.contains("sound") || n.contains("silent") || n.contains("vibrate")) {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val mode = when {
                    v.contains("silent") || v == "off" || v.contains("mute") -> AudioManager.RINGER_MODE_SILENT
                    v.contains("vib") -> AudioManager.RINGER_MODE_VIBRATE
                    else -> AudioManager.RINGER_MODE_NORMAL
                }
                try {
                    am.ringerMode = mode
                } catch (e: SecurityException) {
                    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    if (!nm.isNotificationPolicyAccessGranted) {
                        Actions.launch(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                        return "Silent mode ke liye Do Not Disturb permission do."
                    }
                    return "Ringer mode nahi badal paya."
                }
                return null
            }
            if (n.contains("timeout") || n.contains("screenoff") || n.contains("screen off")) {
                if (!Settings.System.canWrite(ctx)) return needWrite(ctx)
                val secs = v.filter { it.isDigit() }.toIntOrNull() ?: 60
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, secs * 1000)
                return null
            }
            if (n.contains("font")) {
                if (!Settings.System.canWrite(ctx)) return needWrite(ctx)
                val f = v.toFloatOrNull() ?: when {
                    v.contains("big") || v.contains("large") || v.contains("bada") || v.contains("बड़ा") -> 1.3f
                    v.contains("small") || v.contains("chota") || v.contains("छोटा") -> 0.85f
                    else -> 1.0f
                }
                Settings.System.putFloat(ctx.contentResolver, Settings.System.FONT_SCALE, f.coerceIn(0.8f, 1.6f))
                return null
            }
        } catch (e: Exception) {
            return "Ye setting main nahi badal paya."
        }
        return "unknown_setting"
    }

    private fun needWrite(ctx: Context): String {
        Actions.launch(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
        return "System settings badalne ki permission do, phir dobara bolo."
    }

    // ---------------------------------------------------------------- Bluetooth devices

    fun listBluetooth(ctx: Context): String {
        return try {
            @Suppress("DEPRECATION")
            val ad = BluetoothAdapter.getDefaultAdapter() ?: return "Is phone me Bluetooth nahi hai."
            val names = ad.bondedDevices.map { it.name ?: it.address }
            if (names.isEmpty()) "Koi paired Bluetooth device nahi hai." else "Paired devices: " + names.joinToString(", ")
        } catch (e: SecurityException) {
            "Bluetooth ki permission chahiye."
        } catch (e: Exception) {
            "Bluetooth devices nahi mile."
        }
    }

    fun connectBluetooth(ctx: Context, device: String): String? {
        val acc = MaxAccessibilityService.instance ?: return T.needAccessibility(ctx)
        Actions.wakeScreen(ctx)
        val bt = set(ctx, "bluetooth", true)
        if (bt != null && !bt.contains("settings khol")) return bt
        Actions.launch(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        sleep(2500)
        if (acc.clickText(device)) return null
        acc.scroll("down")
        sleep(600)
        return if (acc.clickText(device)) null else "$device Bluetooth list me nahi mila."
    }
}
