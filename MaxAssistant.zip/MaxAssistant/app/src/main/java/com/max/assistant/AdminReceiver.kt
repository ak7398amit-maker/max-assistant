package com.max.assistant

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** Used only to learn about wrong unlock attempts (intruder selfie). */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onPasswordFailed(context: Context, intent: Intent) {
        if (!Prefs.getBool(context, Prefs.K_THEFT_SELFIE, true)) return
        try {
            val i = Intent(context, VoiceService::class.java)
            i.action = VoiceService.ACTION_INTRUDER
            context.startService(i)
        } catch (e: Exception) {
        }
    }
}
