package com.max.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Custom automations: named lists of actions that Max can run by voice or on a daily schedule. */
object Routines {
    private const val KEY = "routines"

    private fun load(ctx: Context): JSONObject =
        try {
            JSONObject(Prefs.get(ctx, KEY, "{}"))
        } catch (e: Exception) {
            JSONObject()
        }

    fun save(ctx: Context, name: String, desc: String, actions: JSONArray) {
        val o = load(ctx)
        o.put(name.trim().lowercase(), JSONObject().put("desc", desc).put("actions", actions))
        Prefs.put(ctx, KEY, o.toString())
    }

    fun get(ctx: Context, name: String): JSONArray? {
        val o = load(ctx)
        val n = name.trim().lowercase()
        if (n.isEmpty()) return null
        val direct = o.optJSONObject(n)
        if (direct != null) return direct.optJSONArray("actions")
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k.contains(n) || n.contains(k)) return o.optJSONObject(k)?.optJSONArray("actions")
        }
        return null
    }

    fun delete(ctx: Context, name: String): Boolean {
        val o = load(ctx)
        val n = name.trim().lowercase()
        if (!o.has(n)) return false
        o.remove(n)
        Prefs.put(ctx, KEY, o.toString())
        return true
    }

    fun list(ctx: Context): List<Pair<String, String>> {
        val o = load(ctx)
        val out = ArrayList<Pair<String, String>>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            out.add(Pair(k, o.optJSONObject(k)?.optString("desc", "") ?: ""))
        }
        return out
    }
}

/** Daily schedules for routines (works while Max is running). */
object Scheduler {
    private const val KEY = "schedules"

    private fun load(ctx: Context): JSONArray =
        try {
            JSONArray(Prefs.get(ctx, KEY, "[]"))
        } catch (e: Exception) {
            JSONArray()
        }

    fun add(ctx: Context, name: String, hour: Int, minute: Int) {
        val old = load(ctx)
        val a = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            if (o.optString("name") != name) a.put(o)
        }
        a.put(JSONObject().put("name", name).put("h", hour).put("m", minute))
        Prefs.put(ctx, KEY, a.toString())
        arm(ctx, name, hour, minute)
    }

    fun cancel(ctx: Context, name: String) {
        val old = load(ctx)
        val a = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            if (o.optString("name") != name) a.put(o)
        }
        Prefs.put(ctx, KEY, a.toString())
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pending(ctx, name, 0, 0))
        } catch (e: Exception) {
        }
    }

    fun armAll(ctx: Context) {
        val a = load(ctx)
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            arm(ctx, o.optString("name"), o.optInt("h"), o.optInt("m"))
        }
    }

    private fun pending(ctx: Context, name: String, h: Int, m: Int): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
        i.putExtra("name", name)
        i.putExtra("h", h)
        i.putExtra("m", m)
        return PendingIntent.getBroadcast(ctx, name.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun arm(ctx: Context, name: String, h: Int, m: Int) {
        try {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, h)
            cal.set(Calendar.MINUTE, m)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= System.currentTimeMillis() + 1000) cal.add(Calendar.DAY_OF_YEAR, 1)
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending(ctx, name, h, m))
        } catch (e: Exception) {
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra("name") ?: return
        val h = intent.getIntExtra("h", 0)
        val m = intent.getIntExtra("m", 0)
        Scheduler.arm(context, name, h, m)
        if (!VoiceService.running) return
        try {
            val i = Intent(context, VoiceService::class.java)
            i.action = VoiceService.ACTION_RUN_ROUTINE
            i.putExtra("name", name)
            context.startService(i)
        } catch (e: Exception) {
        }
    }
}
