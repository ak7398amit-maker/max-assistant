package com.max.assistant

import android.content.Context
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Understands what the user said (offline rules first, then Gemini), speaks the answer and performs the phone actions. */
class Brain(private val ctx: Context, private val speaker: Speaker, private val svc: VoiceService) {

    private val history = ArrayList<GeminiClient.Turn>()

    private class St {
        val errors = ArrayList<String>()
        val deferred = ArrayList<JSONObject>()
        val after = ArrayList<String>()
        var real = 0
    }

    private fun say(text: String) {
        if (text.isBlank()) return
        val latch = CountDownLatch(1)
        UiBus.reply(text)
        UiBus.state(HudState.SPEAKING)
        speaker.speak(text) { latch.countDown() }
        latch.await(90, TimeUnit.SECONDS)
    }

    private fun sleepMs(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    // ------------------------------------------------------------------ prompt

    private fun systemPrompt(): String {
        val name = Prefs.assistantName(ctx)
        val user = Prefs.userName(ctx)
        val lang = Languages.find(Prefs.lang(ctx))
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val mem = Memory.list(ctx)
        val bat = try {
            (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (e: Exception) {
            -1
        }
        val sb = StringBuilder()
        sb.append("You are \"$name\", a hands-free voice assistant living on the user's Android phone, with full control of the phone. ")
        sb.append("Your replies are spoken aloud by text-to-speech, so keep them short, warm and natural.\n")
        if (user.isNotEmpty()) sb.append("The user's name is $user. Use it only occasionally.\n")
        else sb.append("The user's name is not known yet. If the user's message tells you their name, return it with a set_user_name action. Otherwise politely ask for it once.\n")
        sb.append("Reply language: ${lang.english}. If the user clearly speaks another Indian language or English, reply in that language instead.\n")
        sb.append("Current date and time: $now (India). Phone battery: ${if (bat >= 0) "$bat%" else "unknown"}.\n")
        if (mem.isNotEmpty()) {
            sb.append("Things you remember about the user:\n")
            for (m in mem) sb.append("- ").append(m).append('\n')
        }
        val routines = Routines.list(ctx)
        if (routines.isNotEmpty()) {
            sb.append("Saved routines (run with run_routine):\n")
            for (r in routines) sb.append("- ").append(r.first).append(": ").append(r.second).append('\n')
        }
        val ents = SmartHome.entities(ctx)
        if (ents.isNotEmpty()) sb.append("Smart home devices (entity_id | name | state):\n").append(ents)
        val hooks = SmartHome.hookNames(ctx)
        if (hooks.isNotEmpty()) sb.append("Webhooks you can fire with the webhook action: $hooks\n")
        sb.append(
            """
The speech recogniser may mishear words, and the wake word "$name" may appear in the text; ignore it.
Return ONLY a JSON object, no markdown:
{"speech": "what to say aloud (plain text, no emoji, no markdown, at most 2-3 sentences unless asked for detail)",
 "actions": [ {"type": "...", ...} ],
 "remember": ["short durable fact about the user worth remembering, only when the user shares something personal or asks you to remember"]}
"actions" may be empty. "speech" must always be present and must match what you actually do.
Available action types and their fields:
- open_app {app}  (app name in English, e.g. "WhatsApp", "YouTube", "Camera", "Settings", "Phone", "Notes")
- call {to}  (contact name as likely saved, in Latin letters, or a phone number) / answer_call {} / end_call {}
- sms {to, text} / whatsapp {to, text} / whatsapp_call {to, video}
- read_notifications {app}  (read incoming messages out loud; app = "whatsapp" or empty)
- reply {app, to, text}  (reply to the latest notification of that chat directly, without opening the app; to = sender name)
- auto_reply {on: true|false, text, ai: true|false}  (automatic replies to incoming chats while the user is busy)
- do_task {goal}  (FULL PHONE CONTROL: you operate the screen yourself step by step. Use it for anything that needs tapping through an app: creating notes or lists in a notes app, reading or answering chats inside an app, changing any phone setting, installing or navigating apps, playing a specific song, filling forms, Google Home or other smart-home apps, etc. Write the goal as a complete, clear instruction including the exact content, e.g. "Open the Notes app, create a new checklist titled Shopping with the items milk, eggs, bread, and save it")
- web_search {query}  (live internet search for news, weather, scores, prices, facts that may have changed; the answer is spoken afterwards)
- click {text} / type {text} / scroll {direction: up|down|left|right} / back {} / home {} / recents {} / notifications {} / quick_settings {} / lock {} / screenshot {} / power {}
- toggle {what: wifi|bluetooth|data|airplane|hotspot|location|dnd|rotate|nfc|battery_saver|dark, on: true|false}
- system_setting {name: ringer|screen_timeout|font_scale, value}  (ringer: normal|vibrate|silent; screen_timeout in seconds; font_scale like 1.2)
- bluetooth_devices {} (list paired devices) / bluetooth_connect {device}
- torch {on} / volume {level: "up"|"down"|"mute"|"max"|"0-100"} / brightness {percent}
- alarm {hour (0-23), minute, label} / timer {seconds, label}
- youtube {query} / search {query} / open_url {url} / navigate {place}
- where_am_i {} / share_location {to, via: sms|whatsapp} / live_location {on, to, minutes, via} (keep sending the live location every N minutes)
- home {entity_id, service (turn_on|turn_off|toggle|open_cover|close_cover|lock|unlock|set_temperature...), data: {}}  (smart home through Home Assistant, only entity_ids from the list above)
- webhook {name}
- create_routine {name, description, actions: [ ...action objects as above... ]}  (custom automation, e.g. "good morning": torch off, volume 40, web_search weather)
- run_routine {name} / delete_routine {name} / schedule_routine {name, hour, minute} (every day) / cancel_schedule {name}
- selfie {} / photo {} / look_camera {} / look_selfie {} / look_screen {} / read_screen {}
  (for look_camera, look_selfie, look_screen and read_screen put a short acknowledgement in speech; the real answer comes in a second step using the user's original request. look_screen understands pictures, charts, photos and layouts on screen.)
- antitheft {on} / siren {on} / sos {} / battery {}
- set_assistant_name {name} / set_user_name {name} / set_language {code: hi-IN|en-IN|pa-IN|mr-IN|gu-IN|bn-IN|ta-IN|te-IN|kn-IN|ml-IN|ur-IN|or-IN} / forget_memory {}
After you perform an action, the speech must confirm it briefly in the past tense (for example "Done, WhatsApp opened"). For slow actions (whatsapp, whatsapp_call, sos, photos, do_task, toggle) say a short "doing it" line; the app itself adds "done" or the result when it finishes.
Prefer the specific actions above; use do_task when no specific action fits. For general questions, chat, jokes, maths, translations and facts that do not change: answer in "speech" with no actions.
Never invent contacts or numbers. If something is unclear, ask one short question in "speech".
"""
        )
        return sb.toString()
    }

    // ------------------------------------------------------------------ main entry

    fun handle(text: String) {
        val low = text.lowercase()
        // saved routine by name
        val rt = Routines.list(ctx).firstOrNull { it.first.isNotEmpty() && low.contains(it.first) }
        if (rt != null && text.split(" ").size <= rt.first.split(" ").size + 4) {
            say(T.done(ctx))
            runRoutineByName(rt.first)
            return
        }
        // instant offline rules
        val local = try {
            LocalBrain.tryHandle(ctx, svc, text)
        } catch (e: Exception) {
            null
        }
        if (local != null) {
            say(local)
            return
        }
        val raw: String = try {
            GeminiClient.generate(ctx, systemPrompt(), history.toList(), text, null, true)
        } catch (e: Exception) {
            say(Errors.speak(ctx, e))
            return
        }
        val j = JsonUtil.parse(raw)
        val speech = j.optString("speech", "").trim()
        history.add(GeminiClient.Turn("user", text))
        history.add(GeminiClient.Turn("model", speech))
        while (history.size > 16) history.removeAt(0)

        val rem = j.optJSONArray("remember")
        if (rem != null) for (i in 0 until rem.length()) Memory.add(ctx, rem.optString(i))

        val acts = j.optJSONArray("actions") ?: JSONArray()
        val st = St()
        val heavySet = setOf(
            "whatsapp", "whatsapp_call", "sos", "selfie", "photo", "run_routine", "do_task", "web_search", "look_camera",
            "look_selfie", "look_screen", "read_screen", "read_notifications", "toggle", "reply", "share_location",
            "bluetooth_connect", "home"
        )
        val heavy = (0 until acts.length()).any { acts.optJSONObject(it)?.optString("type").orEmpty() in heavySet }
        var spoke = false
        if (speech.isNotEmpty() && heavy) {
            say(speech)
            spoke = true
        }
        process(acts, st, 0)
        if (!spoke && speech.isNotEmpty()) say(speech)
        for (e in st.errors) say(e)
        for (s in st.after) say(s)
        for (d in st.deferred) runDeferred(d, text)
        if (spoke && st.errors.isEmpty() && st.deferred.isEmpty() && st.real > 0) say(T.done(ctx))
    }

    fun runRoutineByName(name: String) {
        val r = Routines.get(ctx, name)
        if (r == null) {
            say("Routine nahi mili.")
            return
        }
        val st = St()
        process(r, st, 1)
        for (e in st.errors) say(e)
        for (s in st.after) say(s)
        for (d in st.deferred) runDeferred(d, name)
    }

    private fun process(acts: JSONArray, st: St, depth: Int) {
        for (i in 0 until acts.length()) {
            val a = acts.optJSONObject(i) ?: continue
            val type = a.optString("type")
            when (type) {
                "look_camera", "look_selfie", "look_screen", "read_screen", "web_search", "do_task", "read_notifications" ->
                    st.deferred.add(a)
                "run_routine" -> {
                    val r = if (depth < 2) Routines.get(ctx, a.optString("name")) else null
                    if (r != null) process(r, st, depth + 1) else st.errors.add("Routine nahi mili.")
                }
                "" -> {}
                else -> {
                    val err = try {
                        exec(type, a, st)
                    } catch (e: Exception) {
                        "Ye kaam nahi ho paya."
                    }
                    st.real++
                    if (err != null) st.errors.add(err)
                    if (depth > 0 || acts.length() > 1) sleepMs(1200)
                }
            }
        }
    }

    private fun runDeferred(d: JSONObject, userText: String) {
        when (val t = d.optString("type")) {
            "look_camera", "look_selfie", "look_screen", "read_screen" -> runVision(t, userText)
            "read_notifications" -> {
                val s = Actions.readNotifications(ctx, d.optString("app").ifBlank { null })
                say(if (s.isBlank()) emptyNotif() else s)
            }
            "web_search" -> runSearch(d.optString("query").ifBlank { userText })
            "do_task" -> say(Agent(ctx).run(d.optString("goal").ifBlank { userText }))
        }
    }

    private fun emptyNotif(): String = when (Prefs.lang(ctx).substringBefore("-")) {
        "hi" -> "कोई नई नोटिफिकेशन नहीं है, या Notification access बंद है।"
        else -> "There are no new notifications, or notification access is off."
    }

    // ------------------------------------------------------------------ actions

    private fun exec(type: String, a: JSONObject, st: St): String? {
        return when (type) {
            "open_app" -> Actions.openApp(ctx, a.optString("app"))
            "call" -> Actions.call(ctx, a.optString("to"))
            "answer_call" -> Actions.answerCall(ctx)
            "end_call" -> Actions.endCall(ctx)
            "sms" -> Actions.sms(ctx, a.optString("to"), a.optString("text"))
            "whatsapp" -> Actions.whatsapp(ctx, a.optString("to"), a.optString("text"))
            "whatsapp_call" -> Actions.whatsappCall(ctx, a.optString("to"), a.optBoolean("video", false))
            "reply" -> {
                val r = NotifService.findReply(a.optString("app").ifBlank { null }, a.optString("to").ifBlank { null })
                if (r == null) "Is chat ki koi nayi notification nahi mili, isliye seedha reply nahi kar sakta."
                else if (NotifService.sendReply(ctx, r, a.optString("text"))) null else "Reply nahi gaya."
            }
            "auto_reply" -> {
                Prefs.putBool(ctx, Prefs.K_AR_ON, a.optBoolean("on", true))
                if (a.has("text") && a.optString("text").isNotBlank()) Prefs.put(ctx, Prefs.K_AR_TEXT, a.optString("text"))
                if (a.has("ai")) Prefs.putBool(ctx, Prefs.K_AR_AI, a.optBoolean("ai", false))
                if (a.optBoolean("on", true) && MaxAccessibilityService.instance == null && !notifAccessOn()) "Auto reply ke liye Notification access ON karo." else null
            }
            "click" -> Actions.click(ctx, a.optString("text"))
            "type" -> Actions.typeText(ctx, a.optString("text"))
            "scroll" -> Actions.scroll(ctx, a.optString("direction", "down"))
            "back", "home", "recents", "notifications", "quick_settings", "lock", "screenshot", "power" -> Actions.global(ctx, type)
            "toggle" -> Toggles.set(ctx, a.optString("what"), a.optBoolean("on", true))
            "wifi", "bluetooth" -> Toggles.set(ctx, type, a.optBoolean("on", true))
            "system_setting" -> {
                val r = Toggles.systemSetting(ctx, a.optString("name"), a.opt("value")?.toString() ?: "")
                if (r == "unknown_setting") "Ye setting direct nahi badal sakta, do_task se karna padega." else r
            }
            "bluetooth_devices" -> {
                st.after.add(Toggles.listBluetooth(ctx))
                null
            }
            "bluetooth_connect" -> Toggles.connectBluetooth(ctx, a.optString("device"))
            "torch" -> Actions.torch(ctx, a.optBoolean("on", true))
            "volume" -> Actions.volume(ctx, a.opt("level")?.toString() ?: "up")
            "brightness" -> Actions.brightness(ctx, a.optInt("percent", 50))
            "alarm" -> Actions.alarm(ctx, a.optInt("hour", 7), a.optInt("minute", 0), a.optString("label", "Max"))
            "timer" -> Actions.timer(ctx, a.optInt("seconds", 60), a.optString("label", "Max"))
            "youtube" -> Actions.youtube(ctx, a.optString("query"))
            "search" -> Actions.search(ctx, a.optString("query"))
            "open_url" -> Actions.openUrl(ctx, a.optString("url"))
            "navigate" -> Actions.navigate(ctx, a.optString("place"))
            "where_am_i" -> {
                st.after.add(LocTools.whereAmI(ctx))
                null
            }
            "share_location" -> LocTools.share(ctx, a.optString("to"), a.optString("via", "sms"))
            "live_location" -> {
                if (a.optBoolean("on", true)) {
                    svc.startLive(a.optString("to"), a.optInt("minutes", 10), a.optString("via", "sms"))
                } else svc.stopLive()
                null
            }
            "home" -> SmartHome.call(ctx, a.optString("entity_id"), a.optString("service", "toggle"), a.optJSONObject("data"))
            "webhook" -> SmartHome.fire(ctx, a.optString("name"))
            "create_routine" -> {
                val arr = a.optJSONArray("actions")
                if (a.optString("name").isBlank() || arr == null) "Routine banane ke liye naam aur steps chahiye."
                else {
                    Routines.save(ctx, a.optString("name"), a.optString("description"), arr)
                    null
                }
            }
            "delete_routine" -> if (Routines.delete(ctx, a.optString("name"))) null else "Ye routine nahi mili."
            "schedule_routine" -> {
                Scheduler.add(ctx, a.optString("name").trim().lowercase(), a.optInt("hour", 7), a.optInt("minute", 0))
                null
            }
            "cancel_schedule" -> {
                Scheduler.cancel(ctx, a.optString("name").trim().lowercase())
                null
            }
            "selfie" -> takePhoto(true)
            "photo" -> takePhoto(false)
            "antitheft" -> {
                svc.setAntiTheft(a.optBoolean("on", true))
                null
            }
            "siren" -> {
                if (a.optBoolean("on", false)) svc.antiTheft.startSiren() else svc.antiTheft.stopSiren()
                null
            }
            "sos" -> Actions.sos(ctx)
            "battery" -> {
                val p = (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                st.after.add("Battery $p percent hai.")
                null
            }
            "wake_screen" -> {
                Actions.wakeScreen(ctx)
                null
            }
            "set_assistant_name" -> {
                val n = a.optString("name").trim()
                if (n.isNotEmpty()) {
                    Prefs.put(ctx, Prefs.K_NAME, n)
                    Prefs.put(ctx, Prefs.K_ALIASES, "")
                }
                null
            }
            "set_user_name" -> {
                val n = a.optString("name").trim()
                if (n.isNotEmpty()) Prefs.put(ctx, Prefs.K_USER, n)
                null
            }
            "set_language" -> {
                val c = a.optString("code")
                if (Languages.all.any { it.code == c }) {
                    Prefs.put(ctx, Prefs.K_LANG, c)
                    speaker.applyLanguage()
                }
                null
            }
            "forget_memory" -> {
                Memory.clear(ctx)
                null
            }
            else -> null
        }
    }

    private fun notifAccessOn(): Boolean {
        val s = android.provider.Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(ctx.packageName)
    }

    private fun capture(front: Boolean): ByteArray? {
        val latch = CountDownLatch(1)
        var out: ByteArray? = null
        svc.camera.capture(front) { b ->
            out = b
            latch.countDown()
        }
        latch.await(15, TimeUnit.SECONDS)
        return out
    }

    private fun takePhoto(front: Boolean): String? {
        val b = capture(front) ?: return "Camera se photo nahi le paya."
        val p = svc.camera.save(b, if (front) "selfie" else "photo")
        return if (p == null) "Photo save nahi hui." else null
    }

    private fun plainSystem(): String {
        val lang = Languages.find(Prefs.lang(ctx))
        return "You are \"${Prefs.assistantName(ctx)}\", a voice assistant. Answer in ${lang.english} (or the language the user spoke), " +
            "in plain spoken sentences with no markdown, no lists and no emoji, in at most 4 short sentences."
    }

    private fun runSearch(query: String) {
        try {
            say(GeminiClient.generate(ctx, plainSystem(), emptyList(), query, null, false, true))
        } catch (e: Exception) {
            say(Errors.speak(ctx, e))
        }
    }

    private fun runVision(type: String, userText: String) {
        val sys = plainSystem()
        try {
            val answer: String = when (type) {
                "look_camera", "look_selfie" -> {
                    val img = capture(type == "look_selfie") ?: run {
                        say("Camera nahi khul paya.")
                        return
                    }
                    GeminiClient.generate(ctx, sys, emptyList(), "User request: $userText\nLook carefully at the photo and answer.", img, false)
                }
                "look_screen" -> {
                    val acc = MaxAccessibilityService.instance
                    if (acc == null) {
                        say(T.needAccessibility(ctx))
                        return
                    }
                    val img = Actions.screenshotSync()
                    val t = acc.readScreen()
                    GeminiClient.generate(
                        ctx, sys, emptyList(),
                        "User request: $userText\nThis is the phone screen. Study the pictures, charts, layout and any text carefully, then answer.\nText found on screen:\n$t",
                        img, false
                    )
                }
                else -> {
                    val acc = MaxAccessibilityService.instance
                    if (acc == null) {
                        say(T.needAccessibility(ctx))
                        return
                    }
                    val t = acc.readScreen()
                    if (t.isBlank()) {
                        say("Screen par koi text nahi dikha.")
                        return
                    }
                    GeminiClient.generate(
                        ctx, sys, emptyList(),
                        "User request: $userText\nText visible on the phone screen. If the user wants it read out, read the important text; otherwise answer:\n$t",
                        null, false
                    )
                }
            }
            say(answer)
        } catch (e: Exception) {
            say(Errors.speak(ctx, e))
        }
    }
}
