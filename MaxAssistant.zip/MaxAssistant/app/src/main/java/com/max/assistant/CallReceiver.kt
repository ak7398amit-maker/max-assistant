package com.max.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (!VoiceService.running) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        @Suppress("DEPRECATION")
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        try {
            val i = Intent(context, VoiceService::class.java)
            i.action = VoiceService.ACTION_CALL_STATE
            i.putExtra("state", state)
            i.putExtra("number", number ?: "")
            context.startService(i)
        } catch (e: Exception) {
        }
    }
}
