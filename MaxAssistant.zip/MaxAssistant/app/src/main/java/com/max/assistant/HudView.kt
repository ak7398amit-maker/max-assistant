package com.max.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Animated JARVIS-style arc reactor. */
class HudView(ctx: Context) : View(ctx) {
    var state: HudState = HudState.OFF
    var title: String = "MAX"

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    private val rect = RectF()

    private fun colorFor(s: HudState): Int = when (s) {
        HudState.OFF -> Color.parseColor("#3A4A5C")
        HudState.IDLE -> Color.parseColor("#00B8D4")
        HudState.LISTENING -> Color.parseColor("#00E5FF")
        HudState.THINKING -> Color.parseColor("#FFC400")
        HudState.SPEAKING -> Color.parseColor("#00E676")
        HudState.ALERT -> Color.parseColor("#FF1744")
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2
        val cy = h / 2
        val r = min(w, h) / 2 * 0.92f
        val t = System.currentTimeMillis() / 1000.0
        val col = colorFor(state)
        val speedMul = when (state) {
            HudState.OFF -> 0.15
            HudState.IDLE -> 0.5
            HudState.LISTENING -> 1.1
            HudState.THINKING -> 2.4
            HudState.SPEAKING -> 1.3
            HudState.ALERT -> 3.0
        }
        val pulse = when (state) {
            HudState.SPEAKING -> 0.5 + 0.5 * sin(t * 9)
            HudState.ALERT -> 0.5 + 0.5 * sin(t * 14)
            HudState.LISTENING -> 0.5 + 0.5 * sin(t * 4)
            else -> 0.5 + 0.5 * sin(t * 1.6)
        }.toFloat()

        // core glow
        val glowR = r * (0.42f + 0.08f * pulse)
        fill.shader = RadialGradient(
            cx, cy, glowR,
            intArrayOf(withAlpha(col, 200), withAlpha(col, 70), withAlpha(col, 0)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, glowR, fill)
        fill.shader = null

        // rings
        val specs = listOf(
            Triple(0.98f, 3f, 0.20), Triple(0.86f, 5f, -0.35), Triple(0.72f, 3f, 0.55),
            Triple(0.58f, 6f, -0.8), Triple(0.46f, 2f, 1.2)
        )
        for ((i, s) in specs.withIndex()) {
            val rr = r * s.first
            ring.strokeWidth = s.second
            ring.color = withAlpha(col, if (i % 2 == 0) 230 else 150)
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
            val base = (t * 60 * s.third * speedMul).toFloat()
            val segs = 3 + i
            val sweep = 360f / segs * 0.62f
            for (k in 0 until segs) {
                c.drawArc(rect, base + k * 360f / segs, sweep, false, ring)
            }
        }

        // tick marks
        ring.strokeWidth = 2f
        ring.color = withAlpha(col, 120)
        val tickBase = (t * 12 * speedMul)
        for (k in 0 until 60) {
            val a = (k * 6.0 + tickBase) * PI / 180
            val inner = r * 1.0f
            val outer = r * (if (k % 5 == 0) 1.07f else 1.03f)
            c.drawLine(
                cx + (cos(a) * inner).toFloat(), cy + (sin(a) * inner).toFloat(),
                cx + (cos(a) * outer).toFloat(), cy + (sin(a) * outer).toFloat(), ring
            )
        }

        // center label
        text.color = Color.WHITE
        text.textSize = r * 0.2f
        text.setShadowLayer(18f, 0f, 0f, col)
        c.drawText(title.uppercase().take(10), cx, cy + text.textSize * 0.35f, text)
        text.clearShadowLayer()
        text.color = withAlpha(col, 220)
        text.textSize = r * 0.07f
        val label = when (state) {
            HudState.OFF -> "OFFLINE"
            HudState.IDLE -> "STANDBY"
            HudState.LISTENING -> "LISTENING"
            HudState.THINKING -> "PROCESSING"
            HudState.SPEAKING -> "SPEAKING"
            HudState.ALERT -> "ALERT"
        }
        c.drawText(label, cx, cy + r * 0.34f, text)

        postInvalidateOnAnimation()
    }

    private fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
}
