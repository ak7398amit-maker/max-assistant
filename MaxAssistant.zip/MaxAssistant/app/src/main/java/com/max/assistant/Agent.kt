package com.max.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import org.json.JSONObject

/** Drives any app on screen, step by step, by reading the screen and letting Gemini choose the next tap. */
class Agent(private val ctx: Context) {

    private val sys = "You operate an Android phone for the user through the accessibility service. " +
        "Each turn you get the GOAL, the steps already done, and a numbered list of the elements currently on screen " +
        "(a screenshot may be attached too). Choose exactly ONE next action and answer with JSON only:\n" +
        "{\"action\": \"click|long_click|type|enter|scroll|back|home|open_app|wait|done|fail\", " +
        "\"index\": number of the element (for click, long_click, type, enter), \"text\": text to type, " +
        "\"direction\": \"up|down|left|right\" (scroll), \"app\": app name (open_app), " +
        "\"say\": short spoken message for the user in the requested language (required for done and fail; " +
        "when the goal was to read or find something, put the actual information in say)}\n" +
        "Rules: use only element numbers from the current list. If the needed app is not open, use open_app first. " +
        "To type, give the index of an EDITABLE element (tap a field first if none is editable). " +
        "After typing in a search box use enter. Use scroll when the item is not visible. " +
        "Finish with done as soon as the goal is achieved. Be efficient. " +
        "Never make payments, transfer money, enter passwords, OTPs or card details, change security settings, " +
        "uninstall apps or delete data unless the goal explicitly asks for that exact action. " +
        "If you hit a login, captcha, biometric prompt or something unsafe, finish with fail and explain."

    private fun sleep(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    fun run(goal: String): String {
        val acc = MaxAccessibilityService.instance ?: return T.needAccessibility(ctx)
        if (!Net.has(ctx)) return T.offline(ctx)
        if (goal.isBlank()) return T.done(ctx)
        Actions.wakeScreen(ctx)
        val lang = Languages.find(Prefs.lang(ctx)).english
        val steps = ArrayList<String>()
        var lastSig = 0
        var same = 0
        for (step in 1..18) {
            sleep(if (step == 1) 1000 else 1100)
            val nodes = acc.snapshot(80)
            val sb = StringBuilder()
            for (n in nodes) {
                sb.append('[').append(n.idx).append("] ").append(n.kind)
                if (n.editable) sb.append(" EDITABLE") else if (n.clickable) sb.append(" CLICKABLE")
                if (n.scrollable) sb.append(" SCROLLABLE")
                sb.append(" \"").append(n.label.replace("\n", " ")).append('"')
                if (n.state.isNotEmpty()) sb.append(" (").append(n.state).append(')')
                sb.append('\n')
            }
            val screen = sb.toString()
            val sig = screen.hashCode()
            same = if (sig == lastSig) same + 1 else 0
            lastSig = sig
            if (same >= 4) return "Screen badal nahi rahi, kaam adhura chhod raha hu."
            val shot = if (nodes.size < 6 || same >= 2) Actions.screenshotSync() else null
            val prompt = "GOAL: $goal\nLanguage for the \"say\" message: $lang\n" +
                "Steps done so far:\n" + (if (steps.isEmpty()) "(none)" else steps.joinToString("\n")) +
                "\n\nCURRENT SCREEN ELEMENTS:\n" + (if (screen.isEmpty()) "(nothing readable)" else screen)
            val raw = try {
                GeminiClient.generate(ctx, sys, emptyList(), prompt, shot, true)
            } catch (e: Exception) {
                return Errors.speak(ctx, e)
            }
            val j = JsonUtil.parse(raw)
            val act = j.optString("action")
            val idx = j.optInt("index", -1)
            val text = j.optString("text")
            steps.add("$step. $act" + (if (idx >= 0) " [$idx]" else "") + (if (text.isNotEmpty()) " \"$text\"" else ""))
            when (act) {
                "done" -> return j.optString("say").ifBlank { T.done(ctx) }
                "fail" -> return j.optString("say").ifBlank { T.agentFail(ctx) }
                "click" -> acc.clickIndex(idx)
                "long_click" -> acc.longClickIndex(idx)
                "type" -> if (idx >= 0) acc.setTextIndex(idx, text) else acc.typeText(text)
                "enter" -> acc.imeEnter(idx)
                "scroll" -> acc.scroll(j.optString("direction", "down"))
                "back" -> acc.global(AccessibilityService.GLOBAL_ACTION_BACK)
                "home" -> acc.global(AccessibilityService.GLOBAL_ACTION_HOME)
                "open_app" -> Actions.openApp(ctx, j.optString("app"))
                "wait" -> sleep(1500)
                else -> {}
            }
        }
        return T.agentFail(ctx)
    }
}

object JsonUtil {
    fun parse(raw: String): JSONObject {
        var s = raw.trim()
        if (s.startsWith("```")) s = s.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a >= 0 && b > a) {
            try {
                return JSONObject(s.substring(a, b + 1))
            } catch (e: Exception) {
            }
        }
        return JSONObject().put("speech", raw.trim())
    }
}

object Errors {
    /** A clear spoken explanation for a failed Gemini call. Also shows the technical detail on screen. */
    fun speak(ctx: Context, e: Exception): String {
        val detail = if (e is GeminiError) "HTTP ${e.code}: ${e.message}" else (e.javaClass.simpleName + ": " + (e.message ?: ""))
        UiBus.reply(detail)
        val hi = Prefs.lang(ctx).startsWith("hi")
        if (e is IllegalStateException) return T.noKey(ctx)
        if (e is GeminiError) {
            when (e.code) {
                400, 401, 403 -> return if (hi) "API key सही नहीं है या उसे इजाज़त नहीं है। Settings में key दोबारा डालिए।"
                else "The API key is wrong or not allowed. Please enter it again in settings."
                429 -> return if (hi) "Gemini की limit पूरी हो गई है। थोड़ी देर बाद कोशिश कीजिए।"
                else "The Gemini limit has been reached. Please try again later."
                else -> {}
            }
        }
        if (e is java.net.UnknownHostException || e is java.net.SocketTimeoutException || e is java.net.ConnectException) {
            return T.offline(ctx)
        }
        return T.netError(ctx)
    }
}
