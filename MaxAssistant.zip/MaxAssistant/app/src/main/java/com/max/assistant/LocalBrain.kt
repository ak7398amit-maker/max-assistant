package com.max.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Understands common commands without internet (and answers them instantly). Returns the spoken reply, or null if not handled. */
object LocalBrain {
    private val ON = setOf("on", "chalu", "चालू", "चालु", "enable", "shuru", "शुरू", "activate", "ऑन", "start")
    private val OFF = setOf("off", "band", "बंद", "बन्द", "disable", "bujha", "बुझा", "ऑफ", "stop")
    private val FILL = setOf(
        "app", "ऐप", "एप", "को", "ko", "karo", "करो", "kar", "कर", "do", "दो", "de", "दे", "please", "the", "a", "ek", "एक",
        "mujhe", "मुझे", "mere", "मेरे", "lagao", "लगाओ", "laga", "लगा", "jara", "ज़रा", "zara", "ji", "जी", "me", "में", "se", "से"
    )

    private fun tokens(s: String): List<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.isNotEmpty() }

    private fun onOff(t: List<String>): Boolean? {
        val on = t.any { it in ON }
        val off = t.any { it in OFF }
        return if (on == off) null else on
    }

    fun tryHandle(ctx: Context, svc: VoiceService?, raw: String): String? {
        val low = raw.lowercase().trim()
        val t = tokens(low)
        if (t.isEmpty()) return null
        val comp = low.replace(Regex("[\\s\\-]"), "")
        val done = T.done(ctx)
        val oo = onOff(t)

        // ---- siren / anti-theft
        if (svc != null) {
            if ((comp.contains("siren") || comp.contains("सायरन") || comp.contains("alarm")) && oo == false) {
                svc.antiTheft.stopSiren()
                return done
            }
            if (comp.contains("antitheft") || comp.contains("एंटीथेफ्ट") || comp.contains("एंटीथैफ्ट") || comp.contains("चोरीअलार्म")) {
                if (oo != null) {
                    svc.setAntiTheft(oo)
                    return done
                }
            }
        }

        // ---- torch
        if (comp.contains("torch") || comp.contains("flashlight") || comp.contains("टॉर्च") || comp.contains("टार्च") || comp.contains("फ्लैशलाइट")) {
            if (oo != null) return Actions.torch(ctx, oo) ?: done
        }

        // ---- connectivity / switches
        val switches = listOf(
            "wifi" to listOf("wifi", "वाईफाई", "वाइफाइ", "वाईफ़ाई"),
            "bluetooth" to listOf("bluetooth", "ब्लूटूथ"),
            "data" to listOf("mobiledata", "मोबाइलडेटा", "mobilenet", "मोबाइलनेट"),
            "airplane" to listOf("airplane", "flightmode", "फ्लाइटमोड", "एयरप्लेन", "विमानमोड"),
            "hotspot" to listOf("hotspot", "हॉटस्पॉट"),
            "location" to listOf("gps", "लोकेशनऑन", "लोकेशनबंद", "locationon", "locationoff"),
            "dnd" to listOf("donotdisturb", "dnd", "डूनॉटडिस्टर्ब"),
            "rotate" to listOf("autorotate", "ऑटोरोटेट", "rotation")
        )
        if (oo != null && !comp.contains("connect") && !comp.contains("जोड़")) {
            for ((key, words) in switches) {
                if (words.any { comp.contains(it) }) return Toggles.set(ctx, key, oo) ?: done
            }
        }

        // ---- volume / brightness
        val num = Regex("(\\d{1,3})").find(low)?.groupValues?.get(1)?.toIntOrNull()
        if (comp.contains("volume") || comp.contains("वॉल्यूम") || comp.contains("आवाज")) {
            val up = t.any { it in setOf("badha", "बढ़ा", "बढ़ाओ", "बढाओ", "increase", "up", "zyada", "ज्यादा", "ज़्यादा", "tez", "तेज़", "तेज", "high") }
            val down = t.any { it in setOf("kam", "कम", "ghata", "घटा", "घटाओ", "decrease", "down", "dheema", "धीमा", "low") }
            val mute = t.any { it == "mute" || it == "म्यूट" }
            val full = t.any { it == "full" || it == "max" || it == "फुल" }
            val lvl = when {
                num != null -> num.toString()
                mute -> "mute"
                full -> "max"
                up && !down -> "up"
                down && !up -> "down"
                else -> null
            }
            if (lvl != null) return Actions.volume(ctx, lvl) ?: done
        }
        if ((comp.contains("brightness") || comp.contains("ब्राइटनेस")) && num != null) {
            return Actions.brightness(ctx, num) ?: done
        }

        // ---- time, date, battery
        if (comp.contains("whattime") || comp.contains("समयक्या") || comp.contains("कितनेबजे") || comp.contains("kitnebaje") || comp.contains("timekya") || comp.contains("टाइमक्या")) {
            val c = Calendar.getInstance()
            val h = if (c.get(Calendar.HOUR) == 0) 12 else c.get(Calendar.HOUR)
            val m = c.get(Calendar.MINUTE)
            return if (Prefs.lang(ctx).startsWith("hi")) "अभी $h बजकर $m मिनट हुए हैं।"
            else String.format(Locale.US, "It is %d:%02d %s.", h, m, if (c.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM")
        }
        if (comp.contains("aajkyadin") || comp.contains("आजकौनसादिन") || comp.contains("आजकायादिन") || comp.contains("todaysdate") || comp.contains("आजकीतारीख") || comp.contains("whatdate")) {
            val hi = Prefs.lang(ctx).startsWith("hi")
            return SimpleDateFormat("EEEE, d MMMM yyyy", if (hi) Locale("hi", "IN") else Locale.ENGLISH).format(Date())
        }
        if (comp.contains("battery") || comp.contains("बैटरी")) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            return if (Prefs.lang(ctx).startsWith("hi")) "बैटरी $p प्रतिशत है।" else "Battery is at $p percent."
        }

        // ---- notifications
        if (comp.contains("notification") || comp.contains("नोटिफिकेशन") || comp.contains("messagepadh") || comp.contains("मैसेजपढ़")) {
            val s = Actions.readNotifications(ctx, if (comp.contains("whatsapp") || comp.contains("व्हाट्सएप")) "whatsapp" else null)
            return if (s.isBlank()) "कोई नई notification नहीं है।" else s
        }

        // ---- location
        if (comp.contains("whereami") || comp.contains("मैंकहाँहूँ") || comp.contains("मेरालोकेशन") || comp.contains("meralocation") || comp.contains("mainkahanhu")) {
            return LocTools.whereAmI(ctx)
        }

        // ---- navigation (short phrases only)
        if (t.size <= 4) {
            val g = when {
                t.contains("back") || t.contains("पीछे") || t.contains("वापस") || t.contains("peeche") -> AccessibilityService.GLOBAL_ACTION_BACK
                t.contains("home") || t.contains("होम") -> AccessibilityService.GLOBAL_ACTION_HOME
                t.contains("recents") || t.contains("recent") || t.contains("रिसेंट") -> AccessibilityService.GLOBAL_ACTION_RECENTS
                t.contains("screenshot") || t.contains("स्क्रीनशॉट") -> AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
                t.contains("lock") || t.contains("लॉक") -> AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
                else -> -1
            }
            if (g != -1) {
                val acc = MaxAccessibilityService.instance ?: return T.needAccessibility(ctx)
                acc.global(g)
                return done
            }
            if (t.contains("scroll") || t.contains("स्क्रॉल")) {
                val dir = if (t.contains("up") || t.contains("ऊपर")) "up" else "down"
                return Actions.scroll(ctx, dir) ?: done
            }
        }

        // ---- open an app
        val openTrig = setOf("open", "kholo", "खोलो", "खोलिए", "खोल", "launch", "kholiye", "khol")
        if (t.any { it in openTrig }) {
            val name = t.filter { it !in openTrig && it !in FILL }.joinToString(" ")
            val words = t.count { it !in openTrig && it !in FILL }
            if (words in 1..3) {
                val pkg = Actions.resolveApp(ctx, name)
                if (pkg != null) {
                    val li = ctx.packageManager.getLaunchIntentForPackage(pkg)
                    if (li != null && Actions.launch(ctx, li)) return done
                }
            }
        }

        // ---- call a contact
        val callTrig = setOf("call", "कॉल", "phone", "फोन", "dial", "फ़ोन")
        val noCall = setOf("whatsapp", "video", "answer", "uthao", "cut", "end", "व्हाट्सएप", "वीडियो", "उठाओ", "काट")
        if (t.any { it in callTrig } && t.none { it in noCall }) {
            val name = t.filter { it !in callTrig && it !in FILL }.joinToString(" ")
            val words = t.count { it !in callTrig && it !in FILL }
            if (words in 1..2) {
                val c = Actions.findContact(ctx, name)
                if (c != null) return Actions.call(ctx, name) ?: done
            }
        }
        return null
    }
}
