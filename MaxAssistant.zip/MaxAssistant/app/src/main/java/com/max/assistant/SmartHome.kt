package com.max.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Smart home through Home Assistant (works on your home Wi-Fi, no internet needed) and simple webhooks. */
object SmartHome {
    private var cache = ""
    private var cacheAt = 0L

    private fun http(method: String, url: String, token: String?, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 4000
            c.readTimeout = 6000
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException("HTTP $code")
            return s
        } finally {
            c.disconnect()
        }
    }

    private fun base(ctx: Context): String = Prefs.get(ctx, Prefs.K_HA_URL).trim().trimEnd('/')

    fun configured(ctx: Context): Boolean = base(ctx).isNotEmpty() && Prefs.get(ctx, Prefs.K_HA_TOKEN).isNotBlank()

    /** "entity_id | name | state" lines for the controllable devices (cached). */
    fun entities(ctx: Context): String {
        if (!configured(ctx)) return ""
        val now = System.currentTimeMillis()
        if (now - cacheAt < 300000) return cache
        cacheAt = now - 240000 // on failure retry in a minute
        try {
            val txt = http("GET", base(ctx) + "/api/states", Prefs.get(ctx, Prefs.K_HA_TOKEN).trim(), null)
            val a = JSONArray(txt)
            val ok = setOf("light", "switch", "fan", "cover", "climate", "lock", "scene", "script", "media_player", "input_boolean")
            val sb = StringBuilder()
            var n = 0
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val id = o.optString("entity_id")
                if (id.substringBefore('.') !in ok) continue
                val name = o.optJSONObject("attributes")?.optString("friendly_name", id) ?: id
                sb.append(id).append(" | ").append(name).append(" | ").append(o.optString("state")).append('\n')
                if (++n >= 80) break
            }
            cache = sb.toString()
            cacheAt = now
        } catch (e: Exception) {
        }
        return cache
    }

    fun call(ctx: Context, entityId: String, service: String, data: JSONObject?): String? {
        if (!configured(ctx)) return "Smart home ke liye Settings me Home Assistant URL aur token daalo."
        if (entityId.isBlank() || !entityId.contains('.')) return "Device ka naam samajh nahi aaya."
        return try {
            val domain = entityId.substringBefore('.')
            val body = JSONObject(data?.toString() ?: "{}").put("entity_id", entityId)
            http("POST", base(ctx) + "/api/services/" + domain + "/" + service.ifBlank { "toggle" }, Prefs.get(ctx, Prefs.K_HA_TOKEN).trim(), body.toString())
            cacheAt = 0
            null
        } catch (e: Exception) {
            "Smart home se connect nahi ho paya."
        }
    }

    private fun hooks(ctx: Context): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        for (line in Prefs.get(ctx, Prefs.K_WEBHOOKS).split("\n", ";")) {
            val i = line.indexOf('=')
            if (i > 0) m[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
        }
        return m
    }

    fun hookNames(ctx: Context): String = hooks(ctx).keys.joinToString(", ")

    fun fire(ctx: Context, name: String): String? {
        val h = hooks(ctx)
        val key = name.trim().lowercase()
        val url = h[key] ?: h.entries.firstOrNull { it.key.contains(key) || key.contains(it.key) }?.value
            ?: return "$name naam ka webhook nahi mila."
        return try {
            http("GET", url, null, null)
            null
        } catch (e: Exception) {
            "Webhook nahi chala."
        }
    }
}
