# Max Assistant (hands-free voice assistant for Android)

Default naam **Max** — app ke andar Settings me kuch bhi rakh sakte ho.

## Features
- Wake word (naam bolo) + hands-free, screen off/background me bhi (foreground service)
- Gemini se baat-cheet: Hindi, English, Punjabi, Marathi, Gujarati, Bengali, Tamil, Telugu, Kannada, Malayalam, Urdu, Odia
- Apna naam puchhta hai, long-term memory (jo batao yaad rakhta hai)
- WhatsApp: voice se message bhejo / call karo / notifications padho
- Incoming call announcer: "XYZ ka call aa raha hai, uthaun?" -> "haan" bolo to utha leta hai (speaker par), "nahi/cut" to kaat deta hai
- Anti-theft: motion + charger nikalne par siren, galat unlock par intruder selfie
- Camera scene analysis ("kya dikh raha hai"), Smart screen text extractor, Screenshot analysis
- Screen par text dekh kar click, scroll, type, back/home, app launcher ("YouTube kholo")
- Call, SMS, alarm, timer, flashlight, volume, brightness, navigation, SOS (location SMS)
- ElevenLabs awaaz (optional)

## APK banane ka tareeka (phone se)
1. Is folder ko GitHub repo me upload karo (main branch).
2. Repo -> Actions -> "Build Max APK" apne aap chalega (ya Run workflow dabao).
3. 3-5 minute baad repo ke **Releases -> Max Assistant (latest build) -> Max-Assistant.apk** download karke install karo.

## Pehli baar setup
1. App kholo -> Settings: **Gemini API key** daalo (aistudio.google.com), apni bhasha chuno.
2. Settings ke niche wale 5-6 buttons se Accessibility, Notification access, Device admin, Overlay, Battery permission ON karo.
3. START dabao, saari permissions Allow karo. Phir bolo: "Max, ..." 

## Dhyan do
- Android me kuch limits hain: lock screen par click/WhatsApp send nahi chalta; Wi-Fi/Bluetooth ka panel khulta hai (Android khud direct toggle nahi karne deta).
- Listening ke liye Google (Speech Recognition) app updated honi chahiye. Kuch bhashaon ki TTS awaaz ke liye phone me us bhasha ka voice data download hona chahiye (ya ElevenLabs use karo).
