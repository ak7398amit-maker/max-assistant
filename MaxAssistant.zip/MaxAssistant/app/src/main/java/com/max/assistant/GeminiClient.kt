package com.max.assistant

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiError(val code: Int, message: String) : RuntimeException(message)

object GeminiClient {
    class Turn(val role: String, val text: String)

    private val fallbackModels = listOf(
        "gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-2.0-flash", "gemini-flash-lite-latest", "gemini-flash-latest"
    )
    private val exhausted = HashMap<String, Long>()

    /** Blocking call. Run on a background thread. Tries the chosen model, then fallbacks if the model is not found. */
    fun generate(
        ctx: Context,
        system: String,
        history: List<Turn>,
        userText: String,
        imageJpeg: ByteArray?,
        json: Boolean
    ): String {
        val key = Prefs.get(ctx, Prefs.K_API).trim()
        if (key.isEmpty()) throw IllegalStateException("NO_KEY")
        val chosen = Prefs.get(ctx, Prefs.K_MODEL, Prefs.DEFAULT_MODEL).trim().ifBlank { Prefs.DEFAULT_MODEL }
        val models = listOf(chosen) + fallbackModels.filter { it != chosen }
        var last: GeminiError? = null
        val now = System.currentTimeMillis()
        // skip models whose daily quota ran out in the last 30 minutes
        val order = models.filter { (exhausted[it] ?: 0L) + 30 * 60 * 1000 < now }.ifEmpty { models }
        for (m in order) {
            try {
                return call(key, m, system, history, userText, imageJpeg, json)
            } catch (e: GeminiError) {
                last = e
                if (e.code == 429) exhausted[m] = System.currentTimeMillis()
                if (e.code != 404 && e.code != 429 && e.code != 503 && e.code != 500) throw e
            }
        }
        throw last ?: GeminiError(0, "unknown")
    }

    private fun call(
        key: String,
        model: String,
        system: String,
        history: List<Turn>,
        userText: String,
        imageJpeg: ByteArray?,
        json: Boolean
    ): String {

        val contents = JSONArray()
        for (t in history) {
            contents.put(
                JSONObject().put("role", t.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", t.text)))
            )
        }
        val parts = JSONArray().put(JSONObject().put("text", userText))
        if (imageJpeg != null) {
            parts.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject().put("mimeType", "image/jpeg")
                        .put("data", Base64.encodeToString(imageJpeg, Base64.NO_WRAP))
                )
            )
        }
        contents.put(JSONObject().put("role", "user").put("parts", parts))

        val gen = JSONObject().put("temperature", 0.6).put("maxOutputTokens", 700)
        if (model.contains("2.5")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        if (json) gen.put("responseMimeType", "application/json")
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", gen)

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                var msg = text.take(300)
                try {
                    msg = JSONObject(text).getJSONObject("error").optString("message", msg)
                } catch (e: Exception) {
                }
                throw GeminiError(code, msg)
            }
            val root = JSONObject(text)
            val cand = root.getJSONArray("candidates").getJSONObject(0)
            val ps = cand.getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text", ""))
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }
}
