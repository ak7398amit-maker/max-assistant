package com.max.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager

/** Everything Max can do on the phone. Each function returns null on success or a short error message to speak. */
object Actions {

    private fun granted(ctx: Context, p: String) =
        ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun launch(ctx: Context, i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            val svc = MaxAccessibilityService.instance
            if (svc != null) svc.startActivity(i) else ctx.startActivity(i)
            true
        } catch (e: Exception) {
            try {
                ctx.startActivity(i)
                true
            } catch (e2: Exception) {
                false
            }
        }
    }

    // ---------------------------------------------------------------- apps

    private val pkgAliases = mapOf(
        "whatsapp" to "com.whatsapp", "whatsapp business" to "com.whatsapp.w4b",
        "youtube" to "com.google.android.youtube", "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana", "telegram" to "org.telegram.messenger",
        "chrome" to "com.android.chrome", "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps", "gmail" to "com.google.android.gm",
        "phonepe" to "com.phonepe.app", "gpay" to "com.google.android.apps.nbu.paisa.user",
        "google pay" to "com.google.android.apps.nbu.paisa.user", "paytm" to "net.one97.paytm",
        "spotify" to "com.spotify.music", "snapchat" to "com.snapchat.android",
        "netflix" to "com.netflix.mediaclient", "twitter" to "com.twitter.android",
        "x" to "com.twitter.android", "play store" to "com.android.vending",
        "photos" to "com.google.android.apps.photos", "meet" to "com.google.android.apps.tachyon"
    )

    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    /** Package name of the best matching launchable app, or null. */
    fun resolveApp(ctx: Context, name: String): String? {
        if (name.isBlank()) return null
        val pm = ctx.packageManager
        val key = name.trim().lowercase()
        val pkg = pkgAliases[key]
        if (pkg != null && pm.getLaunchIntentForPackage(pkg) != null) return pkg
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(q, 0)
        val n = norm(name)
        var best: String? = null
        var bestScore = 0
        for (ri in list) {
            val label = norm(ri.loadLabel(pm).toString())
            val score = when {
                label == n -> 4
                label.startsWith(n) && n.length >= 2 -> 3
                n.length >= 3 && label.contains(n) -> 2
                label.length >= 3 && n.contains(label) -> 1
                else -> 0
            }
            if (score > bestScore) {
                bestScore = score
                best = ri.activityInfo.packageName
            }
        }
        return best
    }

    fun openApp(ctx: Context, name: String): String? {
        if (name.isBlank()) return "App ka naam batao."
        val pkg = resolveApp(ctx, name) ?: return "$name app nahi mila."
        val li = ctx.packageManager.getLaunchIntentForPackage(pkg)
        return if (li != null && launch(ctx, li)) null else "$name app nahi khul paya."
    }

    /** Turns the screen on (needed before driving other apps). */
    @Suppress("DEPRECATION")
    fun wakeScreen(ctx: Context) {
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            if (!pm.isInteractive) {
                val wl = pm.newWakeLock(
                    android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK or android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "max:wake"
                )
                wl.acquire(15000)
            }
        } catch (e: Exception) {
        }
    }

    fun screenshotSync(): ByteArray? {
        val acc = MaxAccessibilityService.instance ?: return null
        val latch = java.util.concurrent.CountDownLatch(1)
        var out: ByteArray? = null
        acc.screenshot { b ->
            out = b
            latch.countDown()
        }
        latch.await(10, java.util.concurrent.TimeUnit.SECONDS)
        return out
    }

    // ---------------------------------------------------------------- contacts / calls / sms

    class Contact(val name: String, val number: String)

    private fun lev(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + c)
        }
        return dp[a.length][b.length]
    }

    fun findContact(ctx: Context, query: String): Contact? {
        val q = query.trim()
        if (q.isEmpty()) return null
        val digits = q.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 7 && q.none { it.isLetter() }) return Contact(q, digits)
        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return null
        val nq = norm(q)
        var best: Contact? = null
        var bestScore = 0
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null
            )?.use { c ->
                var count = 0
                while (c.moveToNext() && count < 5000) {
                    count++
                    val dn = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val nn = norm(dn)
                    if (nn.isEmpty()) continue
                    val score = when {
                        nn == nq -> 100
                        nn.startsWith(nq) -> 80
                        nq.length >= 3 && nn.contains(nq) -> 60
                        nq.length >= 4 && lev(nn, nq) <= 1 -> 55
                        nq.length >= 5 && lev(nn, nq) <= 2 -> 45
                        else -> {
                            val toks = dn.lowercase().split(" ").map { norm(it) }.filter { it.length >= 3 }
                            if (toks.any { it == nq || (nq.length >= 4 && lev(it, nq) <= 1) }) 50 else 0
                        }
                    }
                    if (score > bestScore) {
                        bestScore = score
                        best = Contact(dn, num)
                    }
                }
            }
        } catch (e: Exception) {
        }
        return best
    }

    fun lookupName(ctx: Context, number: String): String? {
        if (number.isBlank() || !granted(ctx, Manifest.permission.READ_CONTACTS)) return null
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    fun call(ctx: Context, to: String): String? {
        val c = findContact(ctx, to) ?: return T.notFound(ctx, to)
        if (!granted(ctx, Manifest.permission.CALL_PHONE)) return "Call ki permission chahiye."
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(c.number)))
        return if (launch(ctx, i)) null else "Call nahi lag paya."
    }

    fun answerCall(ctx: Context): String? {
        return try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            if (!granted(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) return "Call uthane ki permission chahiye."
            tm.acceptRingingCall()
            null
        } catch (e: Exception) {
            "Call nahi utha paya."
        }
    }

    fun endCall(ctx: Context): String? {
        return try {
            if (Build.VERSION.SDK_INT < 28) return "Is Android version par call cut nahi ho sakta."
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            if (!granted(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) return "Call cut karne ki permission chahiye."
            tm.endCall()
            null
        } catch (e: Exception) {
            "Call cut nahi ho paya."
        }
    }

    fun setSpeaker(ctx: Context, on: Boolean) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.isSpeakerphoneOn = on
        } catch (e: Exception) {
        }
    }

    fun sms(ctx: Context, to: String, text: String): String? {
        val c = findContact(ctx, to) ?: return T.notFound(ctx, to)
        if (!granted(ctx, Manifest.permission.SEND_SMS)) return "SMS ki permission chahiye."
        return try {
            val sm = smsManager(ctx)
            val parts = sm.divideMessage(text)
            sm.sendMultipartTextMessage(c.number, null, parts, null, null)
            null
        } catch (e: Exception) {
            "SMS nahi gaya."
        }
    }

    // ---------------------------------------------------------------- WhatsApp

    private fun waNumber(ctx: Context, raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return d
        if (d.startsWith("00")) return d.substring(2)
        if (d.startsWith("0")) d = d.substring(1)
        if (d.length == 10) d = Prefs.countryCode(ctx) + d
        return d
    }

    private fun waPackage(ctx: Context): String? {
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                ctx.packageManager.getPackageInfo(p, 0)
                return p
            } catch (e: Exception) {
            }
        }
        return null
    }

    private val sendTexts = listOf("Send", "भेजें", "ਭੇਜੋ", "पाठवा", "મોકલો", "পাঠান")

    fun whatsapp(ctx: Context, to: String, text: String): String? {
        val pkg = waPackage(ctx) ?: return "WhatsApp install nahi hai."
        val c = findContact(ctx, to) ?: return T.notFound(ctx, to)
        val acc = MaxAccessibilityService.instance ?: return T.needAccessibility(ctx)
        val num = waNumber(ctx, c.number)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num?text=" + Uri.encode(text)))
        i.setPackage(pkg)
        if (!launch(ctx, i)) return "WhatsApp khul nahi paya."
        sleep(2500)
        val ok = acc.clickWhenAvailable(sendTexts, listOf("$pkg:id/send"), 10000)
        return if (ok) null else "Send button nahi mila."
    }

    fun whatsappCall(ctx: Context, to: String, video: Boolean): String? {
        val pkg = waPackage(ctx) ?: return "WhatsApp install nahi hai."
        val c = findContact(ctx, to) ?: return T.notFound(ctx, to)
        val acc = MaxAccessibilityService.instance ?: return T.needAccessibility(ctx)
        val num = waNumber(ctx, c.number)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num"))
        i.setPackage(pkg)
        if (!launch(ctx, i)) return "WhatsApp khul nahi paya."
        sleep(2500)
        val labels = if (video) listOf("Video call", "वीडियो कॉल") else listOf("Voice call", "वॉइस कॉल", "Audio call")
        val ok = acc.clickWhenAvailable(labels, emptyList(), 8000)
        return if (ok) null else "WhatsApp call button nahi mila."
    }

    fun readNotifications(ctx: Context, pkgFilter: String?): String {
        val l = NotifService.recent(6, pkgFilter)
        if (l.isEmpty()) return ""
        val sb = StringBuilder()
        for (n in l) {
            sb.append(n.app).append(": ")
            if (n.title.isNotEmpty()) sb.append(n.title).append(" - ")
            sb.append(n.text).append(". ")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- screen control

    fun click(ctx: Context, text: String): String? {
        val acc = MaxAccessibilityService.instance ?: return T.needAccessibility(ctx)
        return if (acc.clickText(text)) null else "$text screen par nahi mila."
    }

    fun typeText(ctx: Context, text: String): String? {
        val acc = MaxAccessibilityService.instance ?: return T.needAccessibility(ctx)
        return if (acc.typeText(text)) null else "Type karne ki jagah nahi mili."
    }

    fun scroll(ctx: Context, dir: String): String? {
        val acc = MaxAccessibilityService.instance ?: return T.needAccessibility(ctx)
        return if (acc.scroll(dir)) null else "Scroll nahi ho paya."
    }

    fun global(ctx: Context, what: String): String? {
        val acc = MaxAccessibilityService.instance ?: return T.needAccessibility(ctx)
        val a = when (what) {
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            "lock" -> AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
            "screenshot" -> AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
            "power" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
            else -> return null
        }
        acc.global(a)
        return null
    }

    // ---------------------------------------------------------------- device toggles

    fun torch(ctx: Context, on: Boolean): String? {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (cid in cm.cameraIdList) {
                val ch = cm.getCameraCharacteristics(cid)
                val flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val back = ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                if (flash && back) {
                    id = cid
                    break
                }
            }
            if (id == null) "Flashlight nahi mili." else {
                cm.setTorchMode(id, on)
                null
            }
        } catch (e: Exception) {
            "Flashlight nahi chal paayi."
        }
    }

    fun volume(ctx: Context, level: String): String? {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val target = when (level.lowercase()) {
            "up" -> minOf(max, cur + maxOf(1, max / 5))
            "down" -> maxOf(0, cur - maxOf(1, max / 5))
            "mute" -> 0
            "max" -> max
            else -> {
                val p = level.filter { it.isDigit() }.toIntOrNull() ?: return "Volume samajh nahi aaya."
                (max * p.coerceIn(0, 100)) / 100
            }
        }
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        return null
    }

    fun brightness(ctx: Context, percent: Int): String? {
        if (!Settings.System.canWrite(ctx)) {
            launch(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            return "Brightness badalne ki permission do."
        }
        return try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (255 * percent.coerceIn(1, 100)) / 100)
            null
        } catch (e: Exception) {
            "Brightness nahi badal paya."
        }
    }

    fun wifiPanel(ctx: Context): String? {
        val i = if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        else Intent(Settings.ACTION_WIFI_SETTINGS)
        return if (launch(ctx, i)) null else "Wi-Fi settings nahi khuli."
    }

    fun bluetoothPanel(ctx: Context): String? =
        if (launch(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))) null else "Bluetooth settings nahi khuli."

    fun alarm(ctx: Context, hour: Int, minute: Int, label: String): String? {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(ctx, i)) null else "Alarm nahi laga paya."
    }

    fun timer(ctx: Context, seconds: Int, label: String): String? {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(ctx, i)) null else "Timer nahi laga paya."
    }

    // ---------------------------------------------------------------- web / maps

    fun youtube(ctx: Context, query: String): String? {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)))
        try {
            ctx.packageManager.getPackageInfo("com.google.android.youtube", 0)
            i.setPackage("com.google.android.youtube")
        } catch (e: Exception) {
        }
        return if (launch(ctx, i)) null else "YouTube nahi khula."
    }

    fun search(ctx: Context, query: String): String? {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
        return if (launch(ctx, i)) null else "Browser nahi khula."
    }

    fun openUrl(ctx: Context, url: String): String? {
        val u = if (url.startsWith("http")) url else "https://$url"
        return if (launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) null else "Link nahi khula."
    }

    fun navigate(ctx: Context, place: String): String? {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
        i.setPackage("com.google.android.apps.maps")
        if (launch(ctx, i)) return null
        val j = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place)))
        return if (launch(ctx, j)) null else "Maps nahi khula."
    }

    // ---------------------------------------------------------------- SOS

    fun lastLocation(ctx: Context): Location? {
        if (!granted(ctx, Manifest.permission.ACCESS_FINE_LOCATION) && !granted(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)) return null
        return try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
                val l = try {
                    lm.getLastKnownLocation(p)
                } catch (e: Exception) {
                    null
                }
                if (l != null && (best == null || l.time > best.time)) best = l
            }
            best
        } catch (e: Exception) {
            null
        }
    }

    fun sos(ctx: Context): String? {
        val nums = Prefs.get(ctx, Prefs.K_SOS).split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (nums.isEmpty()) return "Settings me emergency number daalo."
        if (!granted(ctx, Manifest.permission.SEND_SMS)) return "SMS ki permission chahiye."
        val loc = lastLocation(ctx)
        val msg = StringBuilder("SOS! Mujhe madad chahiye.")
        if (loc != null) msg.append(" My location: https://maps.google.com/?q=${loc.latitude},${loc.longitude}")
        else msg.append(" Location nahi mili.")
        try {
            val sm = smsManager(ctx)
            for (n in nums) sm.sendMultipartTextMessage(n, null, sm.divideMessage(msg.toString()), null, null)
        } catch (e: Exception) {
            return "SOS SMS nahi gaya."
        }
        if (granted(ctx, Manifest.permission.CALL_PHONE)) {
            launch(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(nums[0]))))
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun sleep(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }
}
