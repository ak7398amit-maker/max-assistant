package com.max.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object LocTools {
    private fun allowed(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Fresh location (waits up to ~10 s), or the last known one. */
    fun current(ctx: Context): Location? {
        if (!allowed(ctx)) return null
        val last = Actions.lastLocation(ctx)
        if (last != null && System.currentTimeMillis() - last.time < 120000) return last
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val latch = CountDownLatch(1)
        var got: Location? = null
        val l = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                got = loc
                latch.countDown()
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}

            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
            }
        }
        try {
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                try {
                    if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, 0L, 0f, l, Looper.getMainLooper())
                } catch (e: Exception) {
                }
            }
            latch.await(10, TimeUnit.SECONDS)
        } catch (e: Exception) {
        } finally {
            try {
                lm.removeUpdates(l)
            } catch (e: Exception) {
            }
        }
        return got ?: last
    }

    fun link(loc: Location): String = "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"

    fun describe(ctx: Context, loc: Location): String {
        try {
            if (Geocoder.isPresent()) {
                @Suppress("DEPRECATION")
                val list = Geocoder(ctx, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)
                val a = list?.firstOrNull()
                val line = a?.getAddressLine(0)
                if (!line.isNullOrBlank()) return line
            }
        } catch (e: Exception) {
        }
        return String.format(Locale.US, "%.5f, %.5f", loc.latitude, loc.longitude)
    }

    fun whereAmI(ctx: Context): String {
        val loc = current(ctx) ?: return "Location nahi mili. Location ON aur permission check karo."
        return "Aap yaha ho: " + describe(ctx, loc)
    }

    fun share(ctx: Context, to: String, via: String): String? {
        val loc = current(ctx) ?: return "Location nahi mili."
        val text = "My live location: " + link(loc)
        return if (via.equals("whatsapp", ignoreCase = true)) Actions.whatsapp(ctx, to, text) else Actions.sms(ctx, to, text)
    }
}
