package com.max.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.concurrent.Executors

/** The always-on brain: listens for the wake word, runs commands, announces calls, guards the phone. */
class VoiceService : Service() {

    companion object {
        const val ACTION_START = "com.max.assistant.START"
        const val ACTION_STOP = "com.max.assistant.STOP"
        const val ACTION_TALK = "com.max.assistant.TALK"
        const val ACTION_CALL_STATE = "com.max.assistant.CALL_STATE"
        const val ACTION_INTRUDER = "com.max.assistant.INTRUDER"
        const val ACTION_SIREN_OFF = "com.max.assistant.SIREN_OFF"
        const val ACTION_ANTITHEFT_TOGGLE = "com.max.assistant.THEFT_TOGGLE"
        private const val CHANNEL = "max_service"
        private const val CHANNEL_ALERT = "max_alert"

        @Volatile
        var running = false
        private var failedAttempts = 0
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var recognizer: SpeechRecognizer? = null
    private lateinit var speaker: Speaker
    private lateinit var brain: Brain
    lateinit var antiTheft: AntiTheft
        private set
    lateinit var camera: CameraHelper
        private set
    private var wakeLock: PowerManager.WakeLock? = null

    private var busy = false
    private var commandMode = false
    private var followUpUntil = 0L
    private var callMode = false
    private var callAnswered = false
    private var inCall = false
    private var stopped = false
    private var errorStreak = 0
    private var mutedBeep = false

    private val restart = Runnable { listen() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        speaker = Speaker(this)
        camera = CameraHelper(this)
        antiTheft = AntiTheft(this) { reason -> onTheft(reason) }
        brain = Brain(this, speaker, this)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "max:listen")
        try {
            wakeLock?.acquire()
        } catch (e: Exception) {
        }
        if (Prefs.getBool(this, Prefs.K_ANTITHEFT, false)) antiTheft.arm()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        val action = intent?.action
        when (action) {
            ACTION_STOP -> {
                stopped = true
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TALK -> {
                speaker.stop()
                busy = false
                commandMode = true
                UiBus.state(HudState.LISTENING)
                resetRecognizer()
                main.postDelayed({ listen() }, 200)
            }
            ACTION_SIREN_OFF -> antiTheft.stopSiren()
            ACTION_ANTITHEFT_TOGGLE -> setAntiTheft(!antiTheft.armed)
            ACTION_CALL_STATE -> handleCallState(intent?.getStringExtra("state") ?: "", intent?.getStringExtra("number") ?: "")
            ACTION_INTRUDER -> handleIntruder()
            else -> {
                if (!started) {
                    started = true
                    firstStart()
                }
            }
        }
        return START_STICKY
    }

    private var started = false

    private fun firstStart() {
        stopped = false
        muteBeep(true)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition service nahi mili. Google app install ya update karo.", false)
            return
        }
        val name = Prefs.assistantName(this)
        val user = Prefs.userName(this)
        if (user.isEmpty()) {
            commandMode = true
            say(T.askName(this, name), true)
        } else {
            say(T.ready(this, name, user), false)
        }
    }

    /** Speak a line, then go back to listening. */
    private fun say(text: String, expectReply: Boolean) {
        busy = true
        resetRecognizer()
        UiBus.reply(text)
        UiBus.state(HudState.SPEAKING)
        speaker.speak(text) {
            busy = false
            if (expectReply) {
                commandMode = true
                UiBus.state(HudState.LISTENING)
            } else {
                UiBus.state(HudState.IDLE)
            }
            listen()
        }
    }

    // ------------------------------------------------------------ listening

    private fun resetRecognizer() {
        main.removeCallbacks(restart)
        try {
            recognizer?.cancel()
        } catch (e: Exception) {
        }
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
    }

    private fun scheduleRestart(ms: Long) {
        main.removeCallbacks(restart)
        main.postDelayed(restart, ms)
    }

    private fun listen() {
        main.removeCallbacks(restart)
        if (stopped || busy || inCall) return
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return
        }
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                recognizer!!.setRecognitionListener(listener)
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang(this))
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, Prefs.lang(this))
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            i.putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1400L)
            recognizer!!.startListening(i)
        } catch (e: Exception) {
            resetRecognizer()
            scheduleRestart(2000)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (stopped || busy) return
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    errorStreak = 0
                    if (commandMode && !callMode) {
                        commandMode = false
                        UiBus.state(HudState.IDLE)
                    }
                    scheduleRestart(250)
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    UiBus.reply("Mic permission chahiye.")
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    resetRecognizer()
                    scheduleRestart(1200)
                }
                else -> {
                    errorStreak++
                    resetRecognizer()
                    scheduleRestart(if (errorStreak > 5) 6000L else 1500L)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            errorStreak = 0
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf<String>()
            handleResults(list)
        }
    }

    private fun handleResults(list: List<String>) {
        val text = list.firstOrNull()?.trim().orEmpty()
        if (text.isEmpty()) {
            scheduleRestart(200)
            return
        }
        if (callMode) {
            handleCallAnswer(list)
            return
        }
        val now = System.currentTimeMillis()
        if (commandMode || now < followUpUntil) {
            commandMode = false
            followUpUntil = 0
            runCommand(text)
            return
        }
        val rem = Wake.extract(list, Wake.words(this))
        if (rem == null) {
            scheduleRestart(100)
        } else if (rem.isBlank()) {
            // wake word only
            busy = true
            resetRecognizer()
            UiBus.state(HudState.SPEAKING)
            speaker.speak(T.ack(this)) {
                busy = false
                commandMode = true
                UiBus.state(HudState.LISTENING)
                listen()
            }
        } else {
            runCommand(rem)
        }
    }

    private fun runCommand(text: String) {
        UiBus.heard(text)
        busy = true
        resetRecognizer()
        UiBus.state(HudState.THINKING)
        val low = text.lowercase()
        if (antiTheft.sounding && (low.contains("stop") || low.contains("band") || low.contains("बंद") || low.contains("बन्द") || low.contains("स्टॉप"))) {
            antiTheft.stopSiren()
        }
        worker.execute {
            try {
                brain.handle(text)
            } catch (e: Exception) {
            }
            main.post {
                busy = false
                followUpUntil = System.currentTimeMillis() + 7000
                UiBus.state(if (antiTheft.sounding) HudState.ALERT else HudState.IDLE)
                listen()
            }
        }
    }

    // ------------------------------------------------------------ calls

    private val yes = setOf(
        "haan", "han", "haa", "ha", "yes", "yeah", "yep", "ok", "okay", "uthao", "utha", "answer", "pick", "sure",
        "हाँ", "हां", "हा", "हान", "उठाओ", "उठा", "उठाइए", "ਹਾਂ", "ਹਾਂਜੀ", "ਚੁੱਕੋ", "હા", "હાં", "ઉપાડો",
        "হ্যাঁ", "হ্যা", "হাঁ", "ধরো", "होय", "हो", "उचल", "उचला"
    )
    private val no = setOf(
        "nahi", "nahin", "nahi", "na", "no", "cut", "reject", "kaat", "kat", "decline", "disconnect",
        "नहीं", "नही", "ना", "काट", "कट", "ਨਹੀਂ", "ਨਹੀ", "ਕੱਟ", "नाही", "नको", "ના", "નહીં", "કાપો", "না", "নাহ", "কাটো"
    )

    private fun handleCallState(state: String, number: String) {
        when (state) {
            "RINGING" -> {
                if (callMode || !Prefs.getBool(this, Prefs.K_ANNOUNCE_CALLS, true)) return
                callMode = true
                callAnswered = false
                commandMode = false
                busy = true
                resetRecognizer()
                val who = Actions.lookupName(this, number) ?: if (number.isNotBlank()) number.toCharArray().joinToString(" ") else "unknown"
                UiBus.state(HudState.SPEAKING)
                UiBus.reply(T.callIn(this, who))
                speaker.speak(T.callIn(this, who)) {
                    busy = false
                    UiBus.state(HudState.LISTENING)
                    listen()
                }
                main.postDelayed({
                    if (callMode && !inCall) {
                        callMode = false
                        listen()
                    }
                }, 45000)
            }
            "OFFHOOK" -> {
                inCall = true
                callMode = false
                resetRecognizer()
                speaker.stop()
                busy = false
                if (callAnswered) {
                    main.postDelayed({ Actions.setSpeaker(this, true) }, 800)
                }
            }
            "IDLE" -> {
                val was = inCall || callMode
                inCall = false
                callMode = false
                if (callAnswered) Actions.setSpeaker(this, false)
                callAnswered = false
                if (was) {
                    busy = false
                    UiBus.state(HudState.IDLE)
                    scheduleRestart(800)
                }
            }
        }
    }

    private fun handleCallAnswer(list: List<String>) {
        var sawYes = false
        var sawNo = false
        for (c in list) {
            val toks = c.lowercase().split(Regex("[\\s,.!?।]+")).filter { it.isNotEmpty() }
            if (toks.any { it in yes }) sawYes = true
            if (toks.any { it in no }) sawNo = true
        }
        if (sawYes && !sawNo) {
            callAnswered = true
            resetRecognizer()
            Actions.answerCall(this)
        } else if (sawNo) {
            callMode = false
            resetRecognizer()
            Actions.endCall(this)
            busy = true
            speaker.speak(T.callRejected(this)) {
                busy = false
                UiBus.state(HudState.IDLE)
                listen()
            }
        } else {
            scheduleRestart(200)
        }
    }

    // ------------------------------------------------------------ anti-theft

    fun setAntiTheft(on: Boolean) {
        if (on) antiTheft.arm() else antiTheft.disarm()
        main.post { UiBus.state(UiBus.state) }
    }

    private fun onTheft(reason: String) {
        if (Prefs.getBool(this, Prefs.K_THEFT_SELFIE, true)) handleIntruder()
        notifyAlert("Anti-theft alarm: $reason")
    }

    private fun handleIntruder() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        failedAttempts++
        if (failedAttempts >= 2 && antiTheft.armed) antiTheft.trigger("wrong unlock")
        camera.capture(true) { bytes ->
            if (bytes != null) {
                val p = camera.save(bytes, "intruder")
                notifyAlert("Intruder photo saved: " + (p ?: ""))
            }
        }
    }

    private fun notifyAlert(text: String) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ALERT, "Max alerts", NotificationManager.IMPORTANCE_HIGH))
            val n = Notification.Builder(this, CHANNEL_ALERT)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(Prefs.assistantName(this))
                .setContentText(text)
                .setAutoCancel(true)
                .build()
            nm.notify((System.currentTimeMillis() % 100000).toInt() + 10, n)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ misc

    private fun muteBeep(on: Boolean) {
        if (on && !Prefs.getBool(this, Prefs.K_SILENT_BEEP, true)) return
        if (on == mutedBeep) return
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val dir = if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
            am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, dir, 0)
            am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, dir, 0)
            mutedBeep = on
        } catch (e: Exception) {
        }
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Max is listening", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(Prefs.assistantName(this) + " is active")
            .setContentText("Say \"" + Prefs.assistantName(this) + "\" to talk")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "STOP", stop).build())
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                var type = 0
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                if (type == 0) {
                    stopSelf()
                    return
                }
                startForeground(1, n, type)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        stopped = true
        running = false
        started = false
        main.removeCallbacksAndMessages(null)
        resetRecognizer()
        try {
            antiTheft.stopSiren()
            antiTheft.disarmKeepFlag()
        } catch (e: Exception) {
        }
        speaker.shutdown()
        muteBeep(false)
        try {
            wakeLock?.release()
        } catch (e: Exception) {
        }
        worker.shutdownNow()
        UiBus.state(HudState.OFF)
        super.onDestroy()
    }
}
