package com.max.assistant

import android.content.Context
import org.json.JSONArray

/** Long-term memory: short facts about the user, kept on the phone and sent to Gemini as context. */
object Memory {
    private const val KEY = "memory_facts"
    private const val MAX = 80

    @Synchronized
    fun list(c: Context): List<String> {
        val raw = Prefs.get(c, KEY, "[]")
        val out = ArrayList<String>()
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    @Synchronized
    fun add(c: Context, fact: String) {
        val f = fact.trim()
        if (f.isEmpty()) return
        val l = ArrayList(list(c))
        if (l.any { it.equals(f, ignoreCase = true) }) return
        l.add(f)
        while (l.size > MAX) l.removeAt(0)
        save(c, l)
    }

    @Synchronized
    fun clear(c: Context) {
        save(c, emptyList())
    }

    private fun save(c: Context, l: List<String>) {
        val a = JSONArray()
        for (s in l) a.put(s)
        Prefs.put(c, KEY, a.toString())
    }
}
