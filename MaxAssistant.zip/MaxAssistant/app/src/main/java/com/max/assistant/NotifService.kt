package com.max.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Keeps the latest notifications so Max can read them out ("WhatsApp pe kya aaya?"). */
class NotifService : NotificationListenerService() {

    class Item(val app: String, val pkg: String, val title: String, val text: String, val time: Long)

    companion object {
        private val items = ArrayList<Item>()

        @Synchronized
        fun recent(max: Int, pkgFilter: String? = null): List<Item> {
            val l = if (pkgFilter == null) items else items.filter { it.pkg.contains(pkgFilter, true) }
            return l.takeLast(max).reversed()
        }

        @Synchronized
        fun add(i: Item) {
            items.add(i)
            while (items.size > 60) items.removeAt(0)
        }

        @Synchronized
        fun clear() {
            items.clear()
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            if (sbn.packageName == packageName) return
            val n = sbn.notification ?: return
            if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
            val ex = n.extras ?: return
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            if (title.isEmpty() && text.isEmpty()) return
            val label = try {
                val pm = packageManager
                pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
            } catch (e: Exception) {
                sbn.packageName
            }
            add(Item(label, sbn.packageName, title, text, sbn.postTime))
        } catch (e: Exception) {
        }
    }
}
