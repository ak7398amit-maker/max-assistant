package com.max.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Keeps the latest notifications so Max can read them out ("WhatsApp pe kya aaya?"). */
class NotifService : NotificationListenerService() {

    class Item(val app: String, val pkg: String, val title: String, val text: String, val time: Long)

    class Reply(val pkg: String, val title: String, val action: Notification.Action, val group: Boolean, val time: Long)

    companion object {
        private val items = ArrayList<Item>()
        private val replies = ArrayList<Reply>()
        private val lastAuto = HashMap<String, Long>()
        private val autoPkgs = setOf(
            "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "com.facebook.orca",
            "com.instagram.android", "com.google.android.apps.messaging", "com.samsung.android.messaging"
        )

        @Synchronized
        fun addReply(r: Reply) {
            replies.removeAll { it.pkg == r.pkg && it.title == r.title }
            replies.add(r)
            while (replies.size > 30) replies.removeAt(0)
        }

        @Synchronized
        fun findReply(app: String?, who: String?): Reply? {
            var a = app?.lowercase()?.trim()
            if (a != null && (a.startsWith("messag") || a.contains("sms"))) a = "messag"
            if (a != null && a.contains("whats")) a = "whatsapp"
            val aa: String = a ?: ""
            val ww: String = who ?: ""
            return replies.lastOrNull {
                (aa.isBlank() || it.pkg.contains(aa, true)) && (ww.isBlank() || it.title.contains(ww, true))
            }
        }

        fun sendReply(ctx: Context, action: Notification.Action, text: String): Boolean {
            return try {
                val ri = action.remoteInputs ?: return false
                val intent = Intent()
                val b = Bundle()
                for (k in ri.indices) b.putCharSequence(ri[k].resultKey, text)
                RemoteInput.addResultsToIntent(ri, intent, b)
                action.actionIntent.send(ctx, 0, intent)
                true
            } catch (e: Exception) {
                false
            }
        }

        fun sendReply(ctx: Context, r: Reply, text: String): Boolean = sendReply(ctx, r.action, text)

        @Synchronized
        fun recent(max: Int, pkgFilter: String? = null): List<Item> {
            val l = if (pkgFilter == null) items else items.filter { it.pkg.contains(pkgFilter, true) }
            return l.takeLast(max).reversed()
        }

        @Synchronized
        fun add(i: Item) {
            items.add(i)
            while (items.size > 60) items.removeAt(0)
        }

        @Synchronized
        fun clear() {
            items.clear()
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            if (sbn.packageName == packageName) return
            val n = sbn.notification ?: return
            if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
            val ex = n.extras ?: return
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            if (title.isEmpty() && text.isEmpty()) return
            val label = try {
                val pm = packageManager
                pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
            } catch (e: Exception) {
                sbn.packageName
            }
            add(Item(label, sbn.packageName, title, text, sbn.postTime))
            val acts = n.actions
            if (acts != null) {
                for (a in acts) {
                    val ri = a.remoteInputs
                    if (ri != null && ri.isNotEmpty()) {
                        val grp = ex.getBoolean("android.isGroupConversation", false)
                        addReply(Reply(sbn.packageName, title, a, grp, sbn.postTime))
                        maybeAutoReply(sbn.packageName, title, text, grp, a)
                        break
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun maybeAutoReply(pkg: String, title: String, text: String, group: Boolean, a: Notification.Action) {
        val c = applicationContext
        if (!Prefs.getBool(c, Prefs.K_AR_ON, false) || group || title.isBlank()) return
        if (pkg !in autoPkgs) return
        val only = Prefs.get(c, Prefs.K_AR_ONLY).split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (only.isNotEmpty() && only.none { title.lowercase().contains(it) }) return
        val key = "$pkg|$title"
        val now = System.currentTimeMillis()
        synchronized(lastAuto) {
            val t = lastAuto[key] ?: 0L
            if (now - t < 10 * 60 * 1000) return
            lastAuto[key] = now
        }
        Thread {
            var reply = Prefs.get(c, Prefs.K_AR_TEXT).trim().ifBlank { "अभी मैं व्यस्त हूँ, थोड़ी देर में बात करता हूँ।" }
            if (Prefs.getBool(c, Prefs.K_AR_AI, false) && Net.has(c)) {
                try {
                    val user = Prefs.userName(c).ifBlank { "the phone owner" }
                    val sys = "You write short chat replies on behalf of $user, who is busy. Reply in the same language and script as the incoming message. " +
                        "Maximum two short sentences, friendly and natural. Do not make promises, share personal information, agree to send money or to meet. " +
                        "If you cannot answer, say $user will reply soon. Output only the reply text."
                    val r = GeminiClient.generate(c, sys, emptyList(), "Message from $title: $text", null, false).trim()
                    if (r.isNotEmpty()) reply = r
                } catch (e: Exception) {
                }
            }
            sendReply(c, a, reply)
        }.start()
    }
}
