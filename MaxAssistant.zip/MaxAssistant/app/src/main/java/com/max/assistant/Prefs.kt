package com.max.assistant

import android.content.Context

object Prefs {
    private const val FILE = "max_prefs"

    const val K_NAME = "assistant_name"
    const val K_USER = "user_name"
    const val K_API = "gemini_key"
    const val K_MODEL = "gemini_model"
    const val K_LANG = "lang"
    const val K_ALIASES = "aliases"
    const val K_EL_KEY = "eleven_key"
    const val K_EL_VOICE = "eleven_voice"
    const val K_SOS = "sos_numbers"
    const val K_CC = "country_code"
    const val K_SILENT_BEEP = "silent_beep"
    const val K_ANNOUNCE_CALLS = "announce_calls"
    const val K_THEFT_SELFIE = "theft_selfie"
    const val K_ANTITHEFT = "antitheft_armed"

    const val DEFAULT_ALIASES = "मैक्स,मैक्स,मेक्स,मॅक्स,ਮੈਕਸ,મેક્સ,ম্যাক্স,macs,maks,mex"
    const val DEFAULT_MODEL = "gemini-2.5-flash"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) {
        sp(c).edit().putString(k, v).apply()
    }

    fun getBool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) {
        sp(c).edit().putBoolean(k, v).apply()
    }

    fun assistantName(c: Context): String = get(c, K_NAME, "Max").trim().ifBlank { "Max" }
    fun userName(c: Context): String = get(c, K_USER, "").trim()
    fun lang(c: Context): String = get(c, K_LANG, "hi-IN")
    fun countryCode(c: Context): String = get(c, K_CC, "91").filter { it.isDigit() }.ifBlank { "91" }
}
