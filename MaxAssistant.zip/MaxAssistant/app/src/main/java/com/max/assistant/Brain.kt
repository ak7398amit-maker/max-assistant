package com.max.assistant

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Understands what the user said (via Gemini), speaks the answer and performs the phone actions. */
class Brain(private val ctx: Context, private val speaker: Speaker, private val svc: VoiceService) {

    private val history = ArrayList<GeminiClient.Turn>()

    private fun say(text: String) {
        if (text.isBlank()) return
        val latch = CountDownLatch(1)
        UiBus.reply(text)
        UiBus.state(HudState.SPEAKING)
        speaker.speak(text) { latch.countDown() }
        latch.await(90, TimeUnit.SECONDS)
    }

    private fun systemPrompt(): String {
        val name = Prefs.assistantName(ctx)
        val user = Prefs.userName(ctx)
        val lang = Languages.find(Prefs.lang(ctx))
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val mem = Memory.list(ctx)
        val sb = StringBuilder()
        sb.append("You are \"$name\", a hands-free voice assistant living on the user's Android phone. ")
        sb.append("Your replies are spoken aloud by text-to-speech, so keep them short, warm and natural.\n")
        if (user.isNotEmpty()) sb.append("The user's name is $user. Use it only occasionally.\n")
        else sb.append("The user's name is not known yet. If the user's message tells you their name, return it with a set_user_name action. Otherwise politely ask for it once.\n")
        sb.append("Reply language: ${lang.english}. If the user clearly speaks another Indian language or English, reply in that language instead.\n")
        sb.append("Current date and time: $now (India).\n")
        if (mem.isNotEmpty()) {
            sb.append("Things you remember about the user:\n")
            for (m in mem) sb.append("- ").append(m).append('\n')
        }
        sb.append(
            """
The speech recogniser may mishear words, and the wake word "$name" may appear in the text; ignore it.
Return ONLY a JSON object, no markdown:
{"speech": "what to say aloud (plain text, no emoji, no markdown, at most 2-3 sentences unless asked for detail)",
 "actions": [ {"type": "...", ...} ],
 "remember": ["short durable fact about the user worth remembering, only when the user shares something personal or asks you to remember"]}
"actions" may be empty. "speech" must always be present and must match what you actually do.
Available action types and their fields:
- open_app {app}  (app name in English, e.g. "WhatsApp", "YouTube", "Camera", "Settings", "Phone")
- call {to}  (contact name as it is likely saved, in Latin letters, or a phone number)
- answer_call {} / end_call {}
- sms {to, text}
- whatsapp {to, text}  (send a WhatsApp text message; write the message in the user's words)
- whatsapp_call {to, video}  (video true/false)
- read_notifications {app}  (app = "whatsapp" or empty for all; speech should say you are reading them)
- click {text}  (tap a button or text visible on the current screen)
- type {text}  (type into the focused text box)
- scroll {direction: up|down|left|right}
- back {} home {} recents {} notifications {} quick_settings {} lock {} screenshot {} power {}
- torch {on: true|false}
- volume {level: "up"|"down"|"mute"|"max"|"0-100"}
- brightness {percent}
- wifi {} / bluetooth {}  (opens the panel)
- alarm {hour (0-23), minute, label}  / timer {seconds, label}
- youtube {query} / search {query} / open_url {url} / navigate {place}
- selfie {} (take a front photo and save to gallery) / photo {} (take a back-camera photo)
- look_camera {} (look through the back camera and describe or answer a question about what is seen)
- look_selfie {} (same with front camera)
- look_screen {} (take a screenshot and answer a question about what is on screen)
- read_screen {} (read out / extract the text on the current screen)
- antitheft {on: true|false}  (anti-theft motion + charger guard with siren)
- siren {on: true|false}
- sos {}  (send emergency SMS with location and call the first emergency contact)
- set_assistant_name {name} / set_user_name {name} / set_language {code: hi-IN|en-IN|pa-IN|mr-IN|gu-IN|bn-IN|ta-IN|te-IN|kn-IN|ml-IN|ur-IN|or-IN}
- forget_memory {}
For look_camera, look_selfie, look_screen and read_screen: put a short acknowledgement in "speech" (like "Let me look"); the real answer is produced in a second step using the user's original request.
For general questions, chat, jokes, maths, translations, news-style knowledge: answer in "speech" with no actions.
Never invent contacts or numbers. If something is unclear, ask one short question in "speech".
"""
        )
        return sb.toString()
    }

    fun handle(text: String) {
        val sys = systemPrompt()
        val raw: String = try {
            GeminiClient.generate(ctx, sys, history.toList(), text, null, true)
        } catch (e: IllegalStateException) {
            fallback(text, T.noKey(ctx))
            return
        } catch (e: Exception) {
            fallback(text, explain(e))
            return
        }
        val j = parse(raw)
        val speech = j.optString("speech", "").trim()
        history.add(GeminiClient.Turn("user", text))
        history.add(GeminiClient.Turn("model", speech))
        while (history.size > 16) history.removeAt(0)

        val rem = j.optJSONArray("remember")
        if (rem != null) for (i in 0 until rem.length()) Memory.add(ctx, rem.optString(i))

        val acts = j.optJSONArray("actions") ?: JSONArray()
        var vision: String? = null
        val errors = ArrayList<String>()
        var spoke = false
        // speak first for actions that take long or that move us away from this app
        if (speech.isNotEmpty()) {
            val heavy = (0 until acts.length()).any {
                val t = acts.optJSONObject(it)?.optString("type").orEmpty()
                t == "whatsapp" || t == "whatsapp_call" || t == "sos" || t == "look_camera" || t == "look_selfie" ||
                    t == "look_screen" || t == "read_screen" || t == "selfie" || t == "photo" || t == "read_notifications"
            }
            if (heavy) {
                say(speech)
                spoke = true
            }
        }
        for (i in 0 until acts.length()) {
            val a = acts.optJSONObject(i) ?: continue
            val type = a.optString("type")
            if (type == "look_camera" || type == "look_selfie" || type == "look_screen" || type == "read_screen") {
                vision = type
                continue
            }
            if (type == "read_notifications") {
                val s = Actions.readNotifications(ctx, a.optString("app").ifBlank { null })
                if (s.isBlank()) say(emptyNotif()) else say(s)
                continue
            }
            val err = exec(type, a)
            if (err != null) errors.add(err)
        }
        if (!spoke && speech.isNotEmpty()) say(speech)
        for (e in errors) say(e)
        if (vision != null) runVision(vision, text)
    }

    /** Turns an API failure into a clear spoken message and shows the technical detail on screen. */
    private fun explain(e: Exception): String {
        val detail = if (e is GeminiError) "HTTP ${e.code}: ${e.message}" else (e.javaClass.simpleName + ": " + (e.message ?: ""))
        UiBus.reply(detail)
        val hi = Prefs.lang(ctx).startsWith("hi")
        if (e is GeminiError) {
            when (e.code) {
                400, 401, 403 -> return if (hi) "API key सही नहीं है या उसे इजाज़त नहीं है। Settings में key दोबारा डालिए।"
                else "The API key is wrong or not allowed. Please enter it again in settings."
                429 -> return if (hi) "Gemini की limit पूरी हो गई है। थोड़ी देर बाद कोशिश कीजिए।"
                else "The Gemini limit has been reached. Please try again later."
                else -> {}
            }
        }
        if (e is java.net.UnknownHostException || e is java.net.SocketTimeoutException || e is java.net.ConnectException) {
            return if (hi) "इंटरनेट नहीं चल रहा।" else "There is no internet connection."
        }
        return T.netError(ctx)
    }

    private fun emptyNotif(): String = when (Prefs.lang(ctx).substringBefore("-")) {
        "hi" -> "कोई नई नोटिफिकेशन नहीं है, या Notification access बंद है।"
        else -> "There are no new notifications, or notification access is off."
    }

    private fun exec(type: String, a: JSONObject): String? {
        return try {
            when (type) {
                "open_app" -> Actions.openApp(ctx, a.optString("app"))
                "call" -> Actions.call(ctx, a.optString("to"))
                "answer_call" -> Actions.answerCall(ctx)
                "end_call" -> Actions.endCall(ctx)
                "sms" -> Actions.sms(ctx, a.optString("to"), a.optString("text"))
                "whatsapp" -> Actions.whatsapp(ctx, a.optString("to"), a.optString("text"))
                "whatsapp_call" -> Actions.whatsappCall(ctx, a.optString("to"), a.optBoolean("video", false))
                "click" -> Actions.click(ctx, a.optString("text"))
                "type" -> Actions.typeText(ctx, a.optString("text"))
                "scroll" -> Actions.scroll(ctx, a.optString("direction", "down"))
                "back", "home", "recents", "notifications", "quick_settings", "lock", "screenshot", "power" ->
                    Actions.global(ctx, type)
                "torch" -> Actions.torch(ctx, a.optBoolean("on", true))
                "volume" -> Actions.volume(ctx, a.opt("level")?.toString() ?: "up")
                "brightness" -> Actions.brightness(ctx, a.optInt("percent", 50))
                "wifi" -> Actions.wifiPanel(ctx)
                "bluetooth" -> Actions.bluetoothPanel(ctx)
                "alarm" -> Actions.alarm(ctx, a.optInt("hour", 7), a.optInt("minute", 0), a.optString("label", "Max"))
                "timer" -> Actions.timer(ctx, a.optInt("seconds", 60), a.optString("label", "Max"))
                "youtube" -> Actions.youtube(ctx, a.optString("query"))
                "search" -> Actions.search(ctx, a.optString("query"))
                "open_url" -> Actions.openUrl(ctx, a.optString("url"))
                "navigate" -> Actions.navigate(ctx, a.optString("place"))
                "selfie" -> takePhoto(true)
                "photo" -> takePhoto(false)
                "antitheft" -> {
                    svc.setAntiTheft(a.optBoolean("on", true))
                    null
                }
                "siren" -> {
                    if (a.optBoolean("on", false)) svc.antiTheft.startSiren() else svc.antiTheft.stopSiren()
                    null
                }
                "sos" -> Actions.sos(ctx)
                "set_assistant_name" -> {
                    val n = a.optString("name").trim()
                    if (n.isNotEmpty()) {
                        Prefs.put(ctx, Prefs.K_NAME, n)
                        Prefs.put(ctx, Prefs.K_ALIASES, "")
                    }
                    null
                }
                "set_user_name" -> {
                    val n = a.optString("name").trim()
                    if (n.isNotEmpty()) Prefs.put(ctx, Prefs.K_USER, n)
                    null
                }
                "set_language" -> {
                    val c = a.optString("code")
                    if (Languages.all.any { it.code == c }) {
                        Prefs.put(ctx, Prefs.K_LANG, c)
                        speaker.applyLanguage()
                    }
                    null
                }
                "forget_memory" -> {
                    Memory.clear(ctx)
                    null
                }
                else -> null
            }
        } catch (e: Exception) {
            "Ye kaam nahi ho paya."
        }
    }

    private fun capture(front: Boolean): ByteArray? {
        val latch = CountDownLatch(1)
        var out: ByteArray? = null
        svc.camera.capture(front) { b ->
            out = b
            latch.countDown()
        }
        latch.await(15, TimeUnit.SECONDS)
        return out
    }

    private fun takePhoto(front: Boolean): String? {
        val b = capture(front) ?: return "Camera se photo nahi le paya."
        val p = svc.camera.save(b, if (front) "selfie" else "photo")
        return if (p == null) "Photo save nahi hui." else null
    }

    private fun screenshot(): ByteArray? {
        val acc = MaxAccessibilityService.instance ?: return null
        val latch = CountDownLatch(1)
        var out: ByteArray? = null
        acc.screenshot { b ->
            out = b
            latch.countDown()
        }
        latch.await(10, TimeUnit.SECONDS)
        return out
    }

    private fun runVision(type: String, userText: String) {
        val lang = Languages.find(Prefs.lang(ctx))
        val sys = "You are \"${Prefs.assistantName(ctx)}\", a voice assistant. Answer in ${lang.english} " +
            "(or the language the user spoke), in plain spoken sentences with no markdown and no emoji, in at most 4 short sentences."
        try {
            val answer: String = when (type) {
                "look_camera", "look_selfie" -> {
                    val img = capture(type == "look_selfie") ?: run {
                        say("Camera nahi khul paya.")
                        return
                    }
                    GeminiClient.generate(ctx, sys, emptyList(), "User request: $userText\nLook at the photo and answer.", img, false)
                }
                "look_screen" -> {
                    if (MaxAccessibilityService.instance == null) {
                        say(T.needAccessibility(ctx))
                        return
                    }
                    val img = screenshot()
                    if (img != null) {
                        GeminiClient.generate(ctx, sys, emptyList(), "User request: $userText\nThis is a screenshot of the phone. Answer.", img, false)
                    } else {
                        val t = MaxAccessibilityService.instance?.readScreen().orEmpty()
                        GeminiClient.generate(ctx, sys, emptyList(), "User request: $userText\nText visible on the phone screen:\n$t", null, false)
                    }
                }
                else -> {
                    val acc = MaxAccessibilityService.instance
                    if (acc == null) {
                        say(T.needAccessibility(ctx))
                        return
                    }
                    val t = acc.readScreen()
                    if (t.isBlank()) {
                        say("Screen par koi text nahi dikha.")
                        return
                    }
                    GeminiClient.generate(
                        ctx, sys, emptyList(),
                        "User request: $userText\nText visible on the phone screen. If the user wants it read out, read the important text; otherwise answer:\n$t",
                        null, false
                    )
                }
            }
            say(answer)
        } catch (e: Exception) {
            say(T.netError(ctx))
        }
    }

    private fun fallback(text: String, msg: String) {
        // very small offline helper: "open <app>"
        val low = text.lowercase()
        val triggers = listOf("kholo", "khol do", "khol", "open", "खोलो", "खोल दो", "खोल", "ਖੋਲ੍ਹੋ", "ਖੋਲ੍ਹ", "उघडा", "ખોલો", "খোলো")
        for (t in triggers) {
            if (low.contains(t)) {
                var app = low.replace(t, " ")
                for (w in listOf("please", "app", "को", "ko", "karo", "kar do", "कर दो", "करो")) app = app.replace(w, " ")
                app = app.trim()
                if (app.isNotEmpty()) {
                    val err = Actions.openApp(ctx, app)
                    if (err == null) return
                }
            }
        }
        say(msg)
    }

    private fun parse(raw: String): JSONObject {
        var s = raw.trim()
        if (s.startsWith("```")) {
            s = s.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        }
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a >= 0 && b > a) {
            try {
                return JSONObject(s.substring(a, b + 1))
            } catch (e: Exception) {
            }
        }
        return JSONObject().put("speech", raw.trim())
    }
}
